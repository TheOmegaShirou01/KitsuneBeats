# Kitsune Beats 0.2.0 release readiness

The project source includes Android code, Setsuna AI/cloud service backend templates and a GitHub Actions build. A passing GitHub Actions Android build and an on-device test are REQUIRED before calling the release finished.

Current unverified items:
- Real APK compilation on GitHub Actions (Android SDK unavailable in the source-preparation environment).
- Signing credentials and certificate SHA-256 (original `.jks` file was reported missing; no such file is in the project).
- Device testing of playback, Android 10+ delete permission, artwork, media session/lock-screen playback seek bar, speech-recognition and notifications.
- Cloudflare Worker and D1 deployment for actual online chat, voiced responses and presence counters.
- Optional GitHub Releases publication and OTA device test.

Release metadata: `applicationId=com.yamanatsuchi.kitsunebeats`, `versionName=0.2.0`, `versionCode=5`. See START_HERE.md for signing, recovery and build workflow. Do not claim the app is complete because a ZIP was generated.
