# GitHub Releases updates for Kitsune Beats

APK builds and signing use **GitHub Actions** (not Google Colab); read `START_HERE.md`.

After the signed APK passes GitHub Actions fingerprint verification **and** device testing, set the repository to **public**, and run the APK build workflow manually with `build_type=release` and `publish_release=true`. GitHub Actions will create the `v0.2.0` Release with the signed APK asset and the exact note marker `KITSUNE_VERSION_CODE=5`. If the release already exists, don't publish again; bump the version code and release tag for subsequent releases.

In Kitsune Beats Settings, set update repository to `TheOmegaShirou01/KitsuneBeats` (if this is where you created the repo). The app checks GitHub Releases' `latest` endpoint, filters for APK assets, compares numeric version codes, verifies SHA-256, application package ID and certificate, then offers Android's normal installation approval. It cannot silently install or bypass Android security.

**Critical:** An app signed with a *different* key cannot update the prior installation, even if the APK has a higher version code. If the original key is lost, follow the guarded one-time new-key procedure in START_HERE.md and expect an uninstall/reinstall once. Never publish a debug-signed APK as an OTA release.
