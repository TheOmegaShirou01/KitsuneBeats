See START_HERE.md for the CURRENT step-by-step GitHub Actions instructions, including lost signing-key handling and optional one-time replacement.
