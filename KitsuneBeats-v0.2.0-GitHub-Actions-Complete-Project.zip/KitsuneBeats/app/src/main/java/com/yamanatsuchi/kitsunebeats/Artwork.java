package com.yamanatsuchi.kitsunebeats;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaMetadataRetriever;
import java.io.File;
import java.io.FileOutputStream;
import java.util.HashMap;
import java.util.Map;

public final class Artwork {
    private Artwork() {}
    private static final Map<Long, Bitmap> thumbnails = new HashMap<>();

    public static File file(Context context, Song song) {
        File dir = new File(context.getFilesDir(), "covers");
        if (!dir.exists()) dir.mkdirs();
        return new File(dir, "song_" + song.id + ".jpg");
    }

    public static synchronized Bitmap cached(Context context, Song song) {
        Bitmap m = thumbnails.get(song.id);
        if (m != null) return m;
        File f = file(context, song);
        if (f.exists()) {
            Bitmap b = BitmapFactory.decodeFile(f.getAbsolutePath());
            if (b != null) { thumbnails.put(song.id, b); return b; }
        }
        return null;
    }

    public static Bitmap loadOrExtract(Context context, Song song) {
        Bitmap found = cached(context, song);
        if (found != null) return found;
        MediaMetadataRetriever mmr = new MediaMetadataRetriever();
        try {
            mmr.setDataSource(context, song.uri);
            byte[] bytes = mmr.getEmbeddedPicture();
            if (bytes == null) return null;
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inSampleSize = 2;
            Bitmap cover = BitmapFactory.decodeByteArray(bytes, 0, bytes.length, options);
            if (cover != null) {
                save(context, song, cover);
                return cover;
            }
        } catch (Exception ignored) {
        } finally {
            try { mmr.release(); } catch (Exception ignored) {}
        }
        return null;
    }

    public static synchronized void save(Context context, Song song, Bitmap image) {
        if (image == null) return;
        Bitmap resized = image;
        if (image.getWidth() > 900 || image.getHeight() > 900) {
            float factor = Math.min(900f / image.getWidth(), 900f / image.getHeight());
            resized = Bitmap.createScaledBitmap(image,
                Math.max(1, Math.round(image.getWidth() * factor)),
                Math.max(1, Math.round(image.getHeight() * factor)), true);
        }
        File dest = file(context, song);
        try (FileOutputStream fos = new FileOutputStream(dest)) {
            resized.compress(Bitmap.CompressFormat.JPEG, 88, fos);
            thumbnails.put(song.id, resized);
        } catch (Exception ignored) {}
    }
}
