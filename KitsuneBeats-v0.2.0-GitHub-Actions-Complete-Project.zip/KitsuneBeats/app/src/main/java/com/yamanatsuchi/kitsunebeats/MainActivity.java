package com.yamanatsuchi.kitsunebeats;

import android.Manifest;
import android.app.Activity;
import android.app.Dialog;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.speech.RecognizerIntent;
import android.media.MediaPlayer;
import org.json.JSONObject;
import java.util.UUID;
import android.speech.tts.TextToSpeech;
import android.speech.tts.Voice;
import android.widget.CheckBox;
import android.app.ProgressDialog;
import android.os.Environment;
import java.util.Locale;
import android.net.Uri;
import android.provider.MediaStore;
import java.util.Collections;
import java.util.Map;
import java.util.TreeMap;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.Window;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int BG = Color.rgb(9,13,31);
    private static final int PANEL = Color.rgb(26,25,54);
    private int backgroundColor(){
        if(prefs==null)return BG;
        int scheme=prefs.getInt("theme_scheme",0);
        return scheme==1?0xff081a30:scheme==2?0xff19191d:scheme==3?0xff1a0b30:BG;
    }
    private int panelColor(){
        if(prefs==null)return PANEL;
        int scheme=prefs.getInt("theme_scheme",0);
        return scheme==1?0xff17304e:scheme==2?0xff33333a:scheme==3?0xff382057:PANEL;
    }
    private static final int WHITE = Color.rgb(246,239,255);
    private static final int MUTED = Color.rgb(192,176,208);
    private static final int PINK = Color.rgb(255,135,217);
    private static final int PURPLE = Color.rgb(136,122,255);
    private static final int AUDIO_PERMISSION = 300;
    private static final int NOTIFICATION_PERMISSION = 301;
    private static final int DELETE_REQUEST = 302;
    private static final int VOICE_REQUEST = 303;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService work = Executors.newFixedThreadPool(3);
    private final ExecutorService metadata = Executors.newSingleThreadExecutor();
    private final List<Song> songs = new ArrayList<>();
    private final List<Song> filtered = new ArrayList<>();
    private final List<OnlineLookup.GameResult> gameResults = new ArrayList<>();
    private PlaybackService playback;
    private boolean bound=false, bindingRequested=false, uiReady=false, seeking=false;
    private int pendingPlay=-1;
    private final List<Song> pendingQueue = new ArrayList<>();
    private int libraryMode = 0; // 0 Songs, 1 Folders, 2 Artists, 3 Genres
    private String selectedGroup = null;
    private final List<String> groups = new ArrayList<>();
    private Button groupsBack;
    private Song pendingDeletion;
    private boolean deleteNeedsRetryOnAndroid10=false;
    private Song selected;
    private ListView songList;
    private BaseAdapter songAdapter;
    private TextView status, nowTitle, nowArtist, currentTime, totalTime, selectedGame;
    private ImageView nowCover;
    private SeekBar seek;
    private Button toggle, shuffle, repeat, tabLibrary, tabSetsuna;
    private LinearLayout libraryPage, setsunaPage, gameResultsContainer;
    private EditText librarySearch, gameSearch;
    private SharedPreferences prefs;
    private TextToSpeech setsunaTts;
    private MediaPlayer setsunaVoice;
    private File currentVoiceFile;
    private long latestVoiceRequest=0;
    private TextView onlineCounts;
    private boolean cloudSpeaking=false;
    private TextView setsunaTip, setsunaAnswer;
    private EditText setsunaQuestion;
    private int setsunaTipCounter=0;
    private boolean updateCheckRunning=false, updateDownloadRunning=false;

    private final ServiceConnection connection=new ServiceConnection() {
        @Override public void onServiceConnected(ComponentName name,IBinder binder) {
            playback=((PlaybackService.LocalBinder)binder).getService();
            bound=true;
            if (pendingPlay>=0 && pendingPlay<songs.size()) {
                int n=pendingPlay;pendingPlay=-1;
                if (!pendingQueue.isEmpty()) {
                    playback.playQueue(new ArrayList<>(pendingQueue), n);
                    pendingQueue.clear();refreshPlayer();
                }
            }
            refreshPlayer();
        }
        @Override public void onServiceDisconnected(ComponentName name) {bound=false;playback=null;}
    };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs=getSharedPreferences("kitsune_library",MODE_PRIVATE);
        setsunaTts=new TextToSpeech(this, statusCode->{
            if(statusCode==TextToSpeech.SUCCESS && setsunaTts!=null) {
                // A network Japanese voice is preferred when the phone provides one.
                // The actual voice and expressiveness depend on installed TTS engines.
                setsunaTts.setLanguage(Locale.JAPAN);
                try {
                    for(Voice v:setsunaTts.getVoices()) {
                        if(v.getLocale().getLanguage().equals("ja") && v.isNetworkConnectionRequired()) {
                            setsunaTts.setVoice(v);break;
                        }
                    }
                }catch(Exception ignored){}
                setsunaTts.setPitch(1.15f);
                setsunaTts.setSpeechRate(1.04f);
            }
        });
        getWindow().setStatusBarColor(backgroundColor());
        getWindow().setNavigationBarColor(backgroundColor());
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        ImageView splash=new ImageView(this);
        splash.setImageResource(R.drawable.splash);
        splash.setBackgroundColor(backgroundColor());
        splash.setScaleType(ImageView.ScaleType.FIT_CENTER);
        setContentView(splash);
        ui.postDelayed(()->{
            if (isFinishing()||isDestroyed())return;
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
            buildInterface();
            uiReady=true;
            ensurePermissionAndScan();
            if(prefs.getBoolean("auto_updates",false))checkForUpdates(false);
            updatePresence();
            long code=prefs.getLong("downloaded_update_code",0L);
            try { if(code>0 && code==GitHubUpdates.installedVersion(this)) {
                prefs.edit().remove("downloaded_update_code").apply();
                toast("Kitsune Beats updated successfully!");
            }}catch(Exception ignored){}
        },2000);
        ui.postDelayed(new Runnable(){
            @Override public void run(){if(!isDestroyed()){if(uiReady)refreshPlayer();ui.postDelayed(this,850);}}
        },1000);
        ui.postDelayed(new Runnable(){
            @Override public void run(){
                if(!isDestroyed()) {
                    if(uiReady)updatePresence();
                    ui.postDelayed(this,60000);
                }
            }
        },60000);
        ui.postDelayed(new Runnable(){
            @Override public void run(){
                if(!isDestroyed()){
                    if(uiReady)updateSetsunaTip();
                    ui.postDelayed(this,45000);
                }
            }
        },5000);
    }

    @Override protected void onStart(){
        super.onStart();
        bindingRequested=bindService(new Intent(this,PlaybackService.class),connection,BIND_AUTO_CREATE);
    }
    @Override protected void onStop(){
        if(bindingRequested){unbindService(connection);bindingRequested=false;}
        bound=false;playback=null;
        super.onStop();
    }
    @Override protected void onDestroy(){
        work.shutdownNow();metadata.shutdownNow();
        if(setsunaTts!=null){setsunaTts.stop();setsunaTts.shutdown();}
        if(setsunaVoice!=null){setsunaVoice.release();setsunaVoice=null;}
        if(currentVoiceFile!=null){currentVoiceFile.delete();currentVoiceFile=null;}
        super.onDestroy();
    }
    private int dp(float v){return Math.round(v*getResources().getDisplayMetrics().density);}
    private GradientDrawable shape(int color,int radius){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp(radius));return g;}
    private GradientDrawable outline(int color){GradientDrawable g=shape(panelColor(),16);g.setStroke(dp(1),color);return g;}
    private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w<0?w:dp(w),h<0?h:dp(h));}
    private TextView text(String value,int size,int color,boolean bold){
        TextView t=new TextView(this);t.setText(value);t.setTextSize(size);t.setTextColor(color);
        if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;
    }
    private Button button(String caption){
        Button b=new Button(this);b.setText(caption);b.setTextColor(WHITE);b.setTextSize(12);
        b.setAllCaps(false);b.setBackground(shape(panelColor(),13));b.setPadding(dp(10),0,dp(10),0);return b;
    }
    private EditText input(String hint){
        EditText e=new EditText(this);e.setSingleLine(true);e.setTextColor(WHITE);e.setHintTextColor(MUTED);
        e.setTextSize(15);e.setHint(hint);e.setBackground(outline(PURPLE));e.setPadding(dp(13),dp(9),dp(13),dp(9));return e;
    }
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
    private String fmt(long millis){long sec=Math.max(0,millis/1000);return String.format(java.util.Locale.US,"%d:%02d",sec/60,sec%60);}

    private void buildInterface(){
        LinearLayout root=col();root.setBackgroundColor(backgroundColor());setContentView(root);
        LinearLayout header=row();header.setPadding(dp(17),dp(8),dp(17),dp(7));
        ImageView mark=new ImageView(this);mark.setImageResource(R.drawable.app_icon);
        header.addView(mark,lp(49,49));
        LinearLayout brand=col();brand.setPadding(dp(12),0,0,0);
        brand.addView(text("KITSUNE BEATS",21,WHITE,true));
        brand.addView(text("WITH SETSUNA AI  •  YAMANATSUCHI INITIATIVE",9,PINK,true));
        header.addView(brand,new LinearLayout.LayoutParams(0,-2,1));
        onlineCounts=text("🟢 —  •  👥 —",10,PINK,true);
        onlineCounts.setGravity(Gravity.CENTER);
        header.addView(onlineCounts,lp(74,46));
        Button settings=button("⚙");settings.setOnClickListener(v->showSettings());header.addView(settings,lp(45,44));
        Button scan=button("⟳");scan.setOnClickListener(v->ensurePermissionAndScan());header.addView(scan,lp(45,44));
        root.addView(header,lp(-1,65));

        LinearLayout tabs=row();tabs.setPadding(dp(13),dp(3),dp(13),dp(5));
        tabLibrary=button("♫   MY LIBRARY");tabSetsuna=button("✦   SETSUNA AI");
        LinearLayout.LayoutParams tabWeight=new LinearLayout.LayoutParams(0,dp(43),1);
        tabWeight.setMargins(dp(3),0,dp(3),0);tabs.addView(tabLibrary,tabWeight);
        LinearLayout.LayoutParams tabWeight2=new LinearLayout.LayoutParams(0,dp(43),1);
        tabWeight2.setMargins(dp(3),0,dp(3),0);tabs.addView(tabSetsuna,tabWeight2);
        tabLibrary.setOnClickListener(v->showTab(false));tabSetsuna.setOnClickListener(v->showTab(true));
        root.addView(tabs,lp(-1,52));
        status=text("Ready to scan for music…",12,MUTED,false);
        status.setPadding(dp(20),dp(1),dp(16),dp(8));root.addView(status,lp(-1,28));
        setsunaTip=text("",11,PINK,false);
        setsunaTip.setPadding(dp(16),dp(5),dp(16),dp(5));
        setsunaTip.setBackground(shape(panelColor(),10));
        LinearLayout.LayoutParams tipLp=lp(-1,-2);
        tipLp.leftMargin=dp(16);tipLp.rightMargin=dp(16);tipLp.bottomMargin=dp(4);
        root.addView(setsunaTip,tipLp);
        setsunaTip.setOnClickListener(v->{
            if(isSetsunaEnabled()){
                showTab(true);
                Song song=chosen();if(song!=null&&gameSearch!=null)gameSearch.setText(song.title+" "+song.artist);
            }
        });
        updateSetsunaTip();

        libraryPage=col();libraryPage.setPadding(dp(16),0,dp(16),0);
        LinearLayout modes=row();
        String[] modeNames={"SONGS","FOLDER","ARTIST","GENRE"};
        for(int mode=0;mode<modeNames.length;mode++) {
            final int m=mode;
            Button b=button(modeNames[mode]);
            LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(0,dp(39),1);
            mp.setMargins(dp(2),0,dp(2),0);
            modes.addView(b,mp);b.setOnClickListener(v->{
                libraryMode=m;selectedGroup=null;filter(librarySearch.getText().toString());
            });
        }
        libraryPage.addView(modes,lp(-1,44));
        groupsBack=button("‹ ALL GROUPS");
        groupsBack.setOnClickListener(v->{selectedGroup=null;filter(librarySearch.getText().toString());});
        libraryPage.addView(groupsBack,lp(-1,36));
        groupsBack.setVisibility(View.GONE);
        librarySearch=input("Search songs, artists, albums…");libraryPage.addView(librarySearch,lp(-1,47));
        librarySearch.addTextChangedListener(new TextWatcher(){
            @Override public void beforeTextChanged(CharSequence s,int st,int count,int after){}
            @Override public void onTextChanged(CharSequence s,int st,int before,int count){filter(s.toString());}
            @Override public void afterTextChanged(Editable e){}
        });
        songList=new ListView(this);songList.setDividerHeight(dp(3));songList.setDivider(null);
        songList.setCacheColorHint(Color.TRANSPARENT);songList.setBackgroundColor(backgroundColor());
        songAdapter=new BaseAdapter(){
            @Override public int getCount(){return isShowingGroups()?groups.size():filtered.size();}
            @Override public Object getItem(int position){return isShowingGroups()?groups.get(position):filtered.get(position);}
            @Override public long getItemId(int position){return isShowingGroups()?position:filtered.get(position).id;}
            @Override public View getView(int position,View view,ViewGroup parent){
                if(isShowingGroups()) {
                    String label=groups.get(position);
                    LinearLayout item=row();item.setBackground(shape(panelColor(),12));item.setPadding(dp(16),dp(16),dp(10),dp(16));
                    TextView title=text("▸   "+label,15,WHITE,true);
                    item.addView(title,lp(-1,-2));return item;
                }
                Song s=filtered.get(position);
                LinearLayout item=row();item.setPadding(dp(8),dp(5),dp(8),dp(5));
                item.setBackground(shape(panelColor(),12));
                ImageView icon=new ImageView(MainActivity.this);
                icon.setScaleType(ImageView.ScaleType.CENTER_CROP);
                icon.setImageResource(R.drawable.fox_default);
                item.addView(icon,lp(51,51));
                work.execute(()->{
                    Bitmap b=Artwork.cached(getApplicationContext(),s);
                    if(b!=null)runOnUiThread(()->{
                        if(s.id==((Long)icon.getTag()).longValue())icon.setImageBitmap(b);
                    });
                });
                icon.setTag(s.id);
                LinearLayout labels=col();labels.setPadding(dp(11),0,0,0);
                TextView title=text(s.title,15,WHITE,true);title.setSingleLine(true);title.setEllipsize(android.text.TextUtils.TruncateAt.END);
                TextView sub=text(s.artist+"   •   "+s.album,11,MUTED,false);
                sub.setSingleLine(true);sub.setEllipsize(android.text.TextUtils.TruncateAt.END);
                labels.addView(title);labels.addView(sub);
                item.addView(labels,new LinearLayout.LayoutParams(0,-2,1));
                item.addView(text(fmt(s.duration),11,PINK,false));
                return item;
            }
        };
        songList.setAdapter(songAdapter);
        songList.setOnItemClickListener((parent,view,pos,id)->{
            if(isShowingGroups()){
                selectedGroup=groups.get(pos);filter(librarySearch.getText().toString());return;
            }
            Song song=filtered.get(pos);selected=song;
            playSong(song);
            ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(librarySearch.getWindowToken(),0);
        });
        songList.setOnItemLongClickListener((parent,view,pos,id)->{
            if(isShowingGroups())return false;
            songMenu(filtered.get(pos));return true;
        });
        libraryPage.addView(songList,new LinearLayout.LayoutParams(-1,0,1));
        root.addView(libraryPage,new LinearLayout.LayoutParams(-1,0,1));

        ScrollView scroll=new ScrollView(this);setsunaPage=col();setsunaPage.setPadding(dp(17),dp(10),dp(17),dp(12));
        ImageView fox=new ImageView(this);fox.setImageResource(R.drawable.setsuna_portrait);
        fox.setScaleType(ImageView.ScaleType.CENTER_CROP);
        LinearLayout.LayoutParams foxLp=lp(105,105);foxLp.gravity=Gravity.CENTER_HORIZONTAL;
        setsunaPage.addView(fox,foxLp);
        TextView setTitle=text("Meet Setsuna AI 🦊",21,WHITE,true);setTitle.setGravity(Gravity.CENTER);
        setsunaPage.addView(setTitle,lp(-1,41));
        TextView intro=text("Hello master. How can I help you today? I can help you search for music, album art, and video game soundtracks.",13,MUTED,false);
        intro.setGravity(Gravity.CENTER);setsunaPage.addView(intro,lp(-1,-2));
        TextView assistantHeading=text("ASK SETSUNA",13,PINK,true);
        assistantHeading.setPadding(0,dp(14),0,dp(6));setsunaPage.addView(assistantHeading);
        LinearLayout asking=row();
        setsunaQuestion=input("Ask Setsuna for help or a recommendation");
        asking.addView(setsunaQuestion,new LinearLayout.LayoutParams(0,dp(46),1));
        Button ask=button("ASK");asking.addView(ask,lp(57,46));setsunaPage.addView(asking);
        setsunaAnswer=text("I can recommend songs, search for covers, and answer questions. Online conversations require the cloud service in Settings.",12,MUTED,false);
        setsunaAnswer.setPadding(dp(6),dp(8),dp(6),dp(8));setsunaPage.addView(setsunaAnswer);
        ask.setOnClickListener(v->answerSetsuna(setsunaQuestion.getText().toString()));
        selectedGame=text("Select a song from your library first.",13,PINK,true);
        selectedGame.setPadding(0,dp(15),0,dp(9));setsunaPage.addView(selectedGame);
        LinearLayout voiceSearch=row();
        gameSearch=input("Search games, albums, songs, artists");
        voiceSearch.addView(gameSearch,new LinearLayout.LayoutParams(0,dp(49),1));
        Button mic=button("🎤");voiceSearch.addView(mic,lp(55,49));
        mic.setOnClickListener(v->beginVoiceSearch());
        setsunaPage.addView(voiceSearch,lp(-1,49));
        Button gameFind=button("✦   FIND ALBUM, SONG OR GAME ARTWORK");
        LinearLayout.LayoutParams findLp=lp(-1,49);findLp.topMargin=dp(12);setsunaPage.addView(gameFind,findLp);
        gameFind.setOnClickListener(v->findGame());
        TextView attribution=text("Results: Apple Music catalog and Wikipedia / Wikimedia. Internet required. Review matches before applying artwork.",11,MUTED,false);
        attribution.setPadding(0,dp(13),0,dp(8));setsunaPage.addView(attribution);
        gameResultsContainer=col();setsunaPage.addView(gameResultsContainer);
        scroll.addView(setsunaPage);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));

        LinearLayout player=col();player.setPadding(dp(14),dp(8),dp(14),dp(12));player.setBackground(outline(accent()));
        LinearLayout playing=row();
        nowCover=new ImageView(this);nowCover.setScaleType(ImageView.ScaleType.CENTER_CROP);
        nowCover.setImageResource(R.drawable.fox_default);playing.addView(nowCover,lp(67,67));
        LinearLayout songNames=col();songNames.setPadding(dp(11),0,dp(5),0);
        nowTitle=text("No song playing",16,WHITE,true);nowArtist=text("Choose a song to begin",12,MUTED,false);
        nowTitle.setSingleLine(true);nowTitle.setEllipsize(android.text.TextUtils.TruncateAt.END);
        nowArtist.setSingleLine(true);nowArtist.setEllipsize(android.text.TextUtils.TruncateAt.END);
        songNames.addView(nowTitle);songNames.addView(nowArtist);
        playing.addView(songNames,new LinearLayout.LayoutParams(0,-2,1));player.addView(playing);
        // Tap the mini-player to open the expanded music controls.
        playing.setOnClickListener(v->showExpandedPlayer());
        LinearLayout timeline=row();currentTime=text("0:00",11,MUTED,false);totalTime=text("0:00",11,MUTED,false);
        seek=new SeekBar(this);seek.setMax(1000);
        timeline.addView(currentTime);timeline.addView(seek,new LinearLayout.LayoutParams(0,dp(34),1));timeline.addView(totalTime);
        player.addView(timeline,lp(-1,38));
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            @Override public void onStartTrackingTouch(SeekBar b){seeking=true;}
            @Override public void onStopTrackingTouch(SeekBar b){
                if(playback!=null)playback.seekTo((int)((long)playback.duration()*b.getProgress()/1000));
                seeking=false;
            }
            @Override public void onProgressChanged(SeekBar b,int progress,boolean fromUser){}
        });
        LinearLayout controls=row();controls.setGravity(Gravity.CENTER);
        shuffle=button("SHUFFLE");repeat=button("REPEAT");
        Button prev=button("◀◀");toggle=button("PLAY ▶");Button next=button("▶▶");
        controls.addView(shuffle,new LinearLayout.LayoutParams(0,dp(43),1));
        controls.addView(prev,new LinearLayout.LayoutParams(0,dp(43),.75f));
        controls.addView(toggle,new LinearLayout.LayoutParams(0,dp(43),1.15f));
        controls.addView(next,new LinearLayout.LayoutParams(0,dp(43),.75f));
        controls.addView(repeat,new LinearLayout.LayoutParams(0,dp(43),1));
        player.addView(controls,lp(-1,43));
        prev.setOnClickListener(v->{if(playback!=null)playback.previous();refreshPlayer();});
        next.setOnClickListener(v->{if(playback!=null)playback.next();refreshPlayer();});
        toggle.setOnClickListener(v->{if(playback!=null)playback.toggle();refreshPlayer();});
        shuffle.setOnClickListener(v->{if(playback!=null)playback.setShuffle(!playback.isShuffle());refreshPlayer();});
        repeat.setOnClickListener(v->{if(playback!=null)playback.cycleRepeat();refreshPlayer();});
        LinearLayout extras=row();
        Button lyrics=button("LYRICS");Button artist=button("ARTIST INFO");Button findCover=button("FIND COVER");
        LinearLayout.LayoutParams e1=new LinearLayout.LayoutParams(0,dp(38),1);
        e1.setMargins(dp(2),dp(8),dp(2),0);
        extras.addView(lyrics,e1);
        LinearLayout.LayoutParams e2=new LinearLayout.LayoutParams(0,dp(38),1);
        e2.setMargins(dp(2),dp(8),dp(2),0);extras.addView(artist,e2);
        LinearLayout.LayoutParams e3=new LinearLayout.LayoutParams(0,dp(38),1);
        e3.setMargins(dp(2),dp(8),dp(2),0);extras.addView(findCover,e3);
        player.addView(extras);root.addView(player,lp(-1,-2));
        lyrics.setOnClickListener(v->showLyrics());
        artist.setOnClickListener(v->showArtist());
        findCover.setOnClickListener(v->{showTab(true);Song s=chosen();if(s!=null)gameSearch.setText(s.album.equals("Unknown album")?s.title:s.album);});
        showTab(false);
    }

    /** Expanded in-app player: Android's own lock screen remains governed by MediaSession. */
    private void showExpandedPlayer(){
        Song first=chosen();
        if(first==null){toast("Choose a song to open Now Playing");return;}
        final Dialog dialog=new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout screen=col();screen.setBackgroundColor(backgroundColor());
        screen.setPadding(dp(22),dp(18),dp(22),dp(25));
        LinearLayout top=row();
        TextView heading=text("NOW PLAYING",18,PINK,true);
        top.addView(heading,new LinearLayout.LayoutParams(0,dp(46),1));
        Button close=button("CLOSE  ✕");
        top.addView(close,lp(96,46));close.setOnClickListener(v->dialog.dismiss());
        screen.addView(top,lp(-1,52));

        ImageView cover=new ImageView(this);
        cover.setImageResource(R.drawable.fox_default);
        cover.setScaleType(ImageView.ScaleType.FIT_CENTER);
        // Leave room for seeking and controls on compact devices.
        int screenHeight=getResources().getDisplayMetrics().heightPixels;
        int imageHeight=Math.max(dp(160),Math.min(dp(320),screenHeight/3));
        LinearLayout.LayoutParams coverLp=new LinearLayout.LayoutParams(-1,imageHeight);
        coverLp.topMargin=dp(18);coverLp.bottomMargin=dp(18);
        screen.addView(cover,coverLp);

        TextView title=text(first.title,21,WHITE,true);
        title.setGravity(Gravity.CENTER);title.setMaxLines(2);
        TextView artist=text(first.artist,15,MUTED,false);artist.setGravity(Gravity.CENTER);
        screen.addView(title,lp(-1,-2));screen.addView(artist,lp(-1,-2));

        LinearLayout timeline=row();
        TextView elapsed=text("0:00",12,MUTED,false);
        TextView total=text("0:00",12,MUTED,false);
        SeekBar fullSeek=new SeekBar(this);fullSeek.setMax(1000);
        timeline.addView(elapsed);timeline.addView(fullSeek,new LinearLayout.LayoutParams(0,dp(55),1));
        timeline.addView(total);
        LinearLayout.LayoutParams timelineLp=lp(-1,58);timelineLp.topMargin=dp(25);
        screen.addView(timeline,timelineLp);

        LinearLayout playbackRow=row();playbackRow.setGravity(Gravity.CENTER);
        Button previous=button("◀◀");Button play=button("PLAY ▶");Button next=button("▶▶");
        playbackRow.addView(previous,new LinearLayout.LayoutParams(0,dp(59),1));
        playbackRow.addView(play,new LinearLayout.LayoutParams(0,dp(59),1.4f));
        playbackRow.addView(next,new LinearLayout.LayoutParams(0,dp(59),1));
        screen.addView(playbackRow,lp(-1,59));
        previous.setOnClickListener(v->{if(playback!=null)playback.previous();refreshPlayer();});
        next.setOnClickListener(v->{if(playback!=null)playback.next();refreshPlayer();});
        play.setOnClickListener(v->{if(playback!=null)playback.toggle();refreshPlayer();});
        final boolean[] userSeeking={false};
        fullSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            @Override public void onStartTrackingTouch(SeekBar bar){userSeeking[0]=true;}
            @Override public void onStopTrackingTouch(SeekBar bar){
                if(playback!=null)playback.seekTo((int)((long)playback.duration()*bar.getProgress()/1000));
                userSeeking[0]=false;
            }
            @Override public void onProgressChanged(SeekBar bar,int progress,boolean fromUser){}
        });
        TextView swipeHint=text("↑ Swipe up on the artwork to close",12,MUTED,false);
        swipeHint.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams hintLp=lp(-1,-2);hintLp.topMargin=dp(19);
        screen.addView(swipeHint,hintLp);
        View.OnTouchListener dismissUp=new View.OnTouchListener(){
            private float startY=0;
            @Override public boolean onTouch(View v,MotionEvent event){
                if(event.getActionMasked()==MotionEvent.ACTION_DOWN){startY=event.getY();return true;}
                if(event.getActionMasked()==MotionEvent.ACTION_UP){
                    if(startY-event.getY()>dp(65))dialog.dismiss();
                    return true;
                }
                return true;
            }
        };
        cover.setOnTouchListener(dismissUp);
        swipeHint.setOnTouchListener(dismissUp);
        dialog.setContentView(screen);
        Window window=dialog.getWindow();
        if(window!=null){window.setLayout(-1,-1);window.setBackgroundDrawableResource(android.R.color.transparent);}

        final long[] lastSong={-1};
        final Runnable updater=new Runnable(){
            @Override public void run(){
                if(!dialog.isShowing()||isDestroyed())return;
                Song current=chosen();
                if(current!=null){
                    title.setText(current.title);artist.setText(current.artist);
                    if(current.id!=lastSong[0]){
                        lastSong[0]=current.id;
                        cover.setImageResource(R.drawable.fox_default);
                        final long requested=current.id;
                        work.execute(()->{
                            Bitmap art=Artwork.loadOrExtract(getApplicationContext(),current);
                            if(art!=null)runOnUiThread(()->{
                                if(dialog.isShowing()&&lastSong[0]==requested)cover.setImageBitmap(art);
                            });
                        });
                    }
                }
                if(playback!=null){
                    int duration=playback.duration(),position=playback.position();
                    if(!userSeeking[0])fullSeek.setProgress(duration>0?(int)(1000L*position/duration):0);
                    elapsed.setText(fmt(position));total.setText(fmt(duration));
                    play.setText(playback.isPlaying()?"PAUSE ❚❚":"PLAY ▶");
                }
                ui.postDelayed(this,650);
            }
        };
        dialog.setOnDismissListener(d->ui.removeCallbacks(updater));
        dialog.show();
        if(dialog.getWindow()!=null)dialog.getWindow().setLayout(-1,-1);
        ui.post(updater);
    }

    private void showTab(boolean ai){
        if(libraryPage==null)return;
        if(ai&&!isSetsunaEnabled()){toast("Setsuna AI is disabled in Settings");return;}
        libraryPage.setVisibility(ai?View.GONE:View.VISIBLE);
        if(setsunaPage!=null)((View)setsunaPage.getParent()).setVisibility(ai?View.VISIBLE:View.GONE);
        tabLibrary.setBackground(shape(ai?panelColor():accent(),12));
        tabSetsuna.setBackground(shape(ai?accent():panelColor(),12));
        if(ai){
            toast("Hello master. How can I help you today?");
            setsunaSpeak("Hello master. How can I help you today?");
        }
        updateSelected();
    }
    private void updateSelected(){if(selectedGame!=null){Song s=chosen();selectedGame.setText(s==null?
        "Select a song from your library first.":"Selected: "+s.title+"  •  "+s.album);}}
    private Song chosen(){return playback!=null&&playback.current()!=null?playback.current():selected;}

    private boolean hasAudioPermission(){
        return checkSelfPermission(Build.VERSION.SDK_INT>=33?Manifest.permission.READ_MEDIA_AUDIO:Manifest.permission.READ_EXTERNAL_STORAGE)==PackageManager.PERMISSION_GRANTED;
    }
    private void ensurePermissionAndScan(){
        if(!hasAudioPermission()){
            status.setText("Allow music access to scan your phone.");
            requestPermissions(new String[]{Build.VERSION.SDK_INT>=33?Manifest.permission.READ_MEDIA_AUDIO:Manifest.permission.READ_EXTERNAL_STORAGE},AUDIO_PERMISSION);
        }else scan();
    }
    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] results){
        super.onRequestPermissionsResult(requestCode,permissions,results);
        if(requestCode==AUDIO_PERMISSION){
            if(hasAudioPermission())scan();
            else if(status!=null)status.setText("Music access denied. Tap ⟳ to try again.");
        }
    }
    private void scan(){
        status.setText("Scanning audio files…");
        work.execute(()->{
            try {
                List<Song> found=MusicLibrary.scan(getApplicationContext());
                runOnUiThread(()->{
                    songs.clear();songs.addAll(found);
                    for(Song song:songs) {
                        String renamed=prefs.getString("renamed_title_"+song.id,null);
                        if(renamed!=null&&!renamed.trim().isEmpty())song.title=renamed.trim();
                    }
                    filter(librarySearch.getText().toString());
                    status.setText(found.size()==0?"No music found. Add audio files and tap ⟳.":
                        found.size()+" songs found  •  Offline playback ready");
                    startCoverCheck(found);
                    updateSetsunaTip();
                });
            } catch(Exception ex){runOnUiThread(()->status.setText("Scan failed: "+ex.getMessage()));}
        });
    }
    private int accent(){return prefs==null?PURPLE:prefs.getInt("theme_accent",PURPLE);}
    private boolean isSetsunaEnabled(){return prefs==null||prefs.getBoolean("setsuna_enabled",true);}
    private String cloudUrl(){return prefs.getString("cloud_service_url","").trim();}
    private boolean onlineAssistant(){return isSetsunaEnabled() && prefs.getBoolean("online_setsuna_consent",false) && !cloudUrl().isEmpty();}
    private void localSpeak(String message){
        if(setsunaTts!=null)try{setsunaTts.speak(message,TextToSpeech.QUEUE_FLUSH,null,"setsuna_reply");}
        catch(Exception ignored){}
    }
    private void setsunaSpeak(String message){
        if(!isSetsunaEnabled())return;
        // Associate requests with a sequence to prevent older cloud replies overwriting newer speech.
        final long request=++latestVoiceRequest;
        if(!onlineAssistant()){localSpeak(message);return;}
        work.execute(()->{
            File recording=null;
            try {
                recording=KitsuneCloud.speech(getApplicationContext(),cloudUrl(),message);
                File readyFile=recording;
                runOnUiThread(()->{
                    if(!isSetsunaEnabled()||isDestroyed()||request!=latestVoiceRequest){readyFile.delete();return;}
                    try {
                        if(setsunaVoice!=null){setsunaVoice.release();setsunaVoice=null;}
                        if(currentVoiceFile!=null){currentVoiceFile.delete();currentVoiceFile=null;}
                        currentVoiceFile=readyFile;
                        setsunaVoice=new MediaPlayer();
                        setsunaVoice.setDataSource(readyFile.getAbsolutePath());
                        setsunaVoice.setOnCompletionListener(mp->{
                            mp.release();
                            if(setsunaVoice==mp){setsunaVoice=null;}
                            if(currentVoiceFile==readyFile){currentVoiceFile.delete();currentVoiceFile=null;}
                        });
                        setsunaVoice.prepare();setsunaVoice.start();
                    }catch(Exception e){
                        readyFile.delete();currentVoiceFile=null;
                        if(setsunaVoice!=null){setsunaVoice.release();setsunaVoice=null;}
                        localSpeak(message);
                    }
                });
            } catch(Exception e){runOnUiThread(()->{
                if(!isDestroyed()&&request==latestVoiceRequest)localSpeak(message);
            });}
        });
    }
    private String installationId(){
        String id=prefs.getString("anonymous_installation_id","");
        if(id.isEmpty()){
            id=UUID.randomUUID().toString();
            prefs.edit().putString("anonymous_installation_id",id).apply();
        }
        return id;
    }
    private void updatePresence(){
        if(onlineCounts==null)return;
        if(!prefs.getBoolean("anonymous_presence_consent",false) || cloudUrl().isEmpty()){
            onlineCounts.setText("🟢 —  •  👥 —");return;
        }
        String endpoint=cloudUrl(),uuid=installationId();
        work.execute(()->{
            try {
                JSONObject result=KitsuneCloud.presence(endpoint,uuid);
                String label="🟢 "+result.optInt("online",0)+"  •  👥 "+result.optInt("total",0);
                runOnUiThread(()->{if(onlineCounts!=null&&!isDestroyed()&&
                    prefs.getBoolean("anonymous_presence_consent",false))onlineCounts.setText(label);});
            }catch(Exception e){runOnUiThread(()->{
                if(onlineCounts!=null&&!isDestroyed())onlineCounts.setText("🟢 —  •  👥 —");
            });}
        });
    }
    private void beginVoiceSearch(){
        if(!isSetsunaEnabled()){toast("Enable Setsuna AI in Settings");return;}
        try{
            Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            i.putExtra(RecognizerIntent.EXTRA_PROMPT,"What would you like Setsuna to search?");
            startActivityForResult(i,VOICE_REQUEST);
        }catch(Exception e){toast("Voice recognition is not available on this phone");}
    }

    private void updateSetsunaTip(){
        if(setsunaTip==null)return;
        setsunaTip.setVisibility(isSetsunaEnabled()?View.VISIBLE:View.GONE);
        if(!isSetsunaEnabled())return;
        String[] ideas={
            "🦊 Setsuna: Tap here if you need help finding album artwork.",
            "🦊 Setsuna: Want a recommendation? Ask me on my tab!",
            "🦊 Setsuna: You can long-press a song to rename or delete it.",
            "🦊 Setsuna: Try the Folder, Artist and Genre tabs to explore your library."
        };
        setsunaTip.setText(ideas[(setsunaTipCounter++)%ideas.length]);
    }
    private boolean isQuickHelpCommand(String input){
        String q=input==null?"":input.toLowerCase(Locale.ROOT);
        return q.contains("recommend")||q.contains("suggest")||q.contains("surprise me")
            ||q.contains("help")||q.contains("how do i")||q.contains("how to")
            ||q.contains("what can you")||q.contains("hello setsuna");
    }
    private void answerSetsuna(String input){
        if(!isSetsunaEnabled()){toast("Enable Setsuna in Settings");return;}
        String query=input==null?"":input.trim();
        if(query.isEmpty()){toast("Ask Setsuna a question first");return;}
        String simple=query.toLowerCase(Locale.ROOT).trim();
        if((simple.startsWith("find ")||simple.startsWith("search ")) &&
              (simple.contains("cover")||simple.contains("artwork")||simple.contains("album art"))){
            String title=query.replaceFirst("(?i)^(find|search)( for)?\\s+","")
                .replaceFirst("(?i)\\s+(album\\s+)?(cover|artwork|album art).*?$","").trim();
            if(!title.isEmpty()){
                if(gameSearch!=null)gameSearch.setText(title);
                showTab(true);
                findGame();
                if(setsunaAnswer!=null)setsunaAnswer.setText("I'll search for artwork matching: "+title);
                setsunaSpeak("Searching for artwork, master.");
                return;
            }
        }
        if(simple.startsWith("play ") && !songs.isEmpty()){
            String title=simple.substring(5).trim();
            for(Song candidate:songs){
                if(candidate.title.toLowerCase(Locale.ROOT).contains(title) ||
                   candidate.artist.toLowerCase(Locale.ROOT).equals(title)){
                    playSong(candidate);
                    String reply="Playing "+candidate.title+" by "+candidate.artist+", master.";
                    if(setsunaAnswer!=null)setsunaAnswer.setText(reply);
                    setsunaSpeak(reply);return;
                }
            }
        }
        if(onlineAssistant()){
            if(setsunaAnswer!=null)setsunaAnswer.setText("Setsuna is thinking…");
            String endpoint=cloudUrl();
            ArrayList<Song> localCopy=new ArrayList<>(songs);
            work.execute(()->{
                try {
                    String reply=KitsuneCloud.answer(endpoint,query,localCopy);
                    runOnUiThread(()->{
                        if(!isSetsunaEnabled()||isDestroyed())return;
                        if(setsunaAnswer!=null)setsunaAnswer.setText(reply);
                        setsunaSpeak(reply);
                    });
                }catch(Exception e){runOnUiThread(()->{
                    if(setsunaAnswer!=null)setsunaAnswer.setText("Online Setsuna unavailable: "+e.getMessage()+
                        "\nYou can still browse your music and search artwork locally.");
                });}
            });
            return;
        }
        String q=query.toLowerCase(Locale.ROOT);
        String response;
        if(q.contains("recommend")||q.contains("suggest")||q.contains("surprise me")){
            if(songs.isEmpty())response="Master, I can't recommend a track until you've scanned your music library.";
            else {
                Song pick=songs.get((int)(System.currentTimeMillis()/60000 % songs.size()));
                response="Master, how about listening to "+pick.title+" by "+pick.artist+"? It's in your music library!";
            }
        } else if(q.contains("artwork")||q.contains("cover")||q.contains("album art")){
            response="I can look for covers! Type a song, album, game, or artist in the artwork search below, or use the microphone.";
        } else if(q.contains("rename")||q.contains("delete")){
            response="Long-press a song in your library. Rename only changes the title shown in Kitsune Beats; Delete removes the real file after confirmation.";
        } else if(q.contains("folder")||q.contains("genre")||q.contains("artist tab")){
            response="You can browse your music using the Folder, Artist, and Genre tabs in My Library!";
        } else if(q.contains("hello")||q.contains("hi setsuna")){
            response="Hello master. How can I help you today?";
        } else if(q.contains("help")||q.contains("what can")||q.contains("how do")){
            response="I can recommend tracks from your library, help find artwork, and show how to rename, delete or browse songs. For open-ended conversations, configure the online AI service in Settings.";
        } else {
            response="I can help with artwork, the music library, or a recommendation. Try one of those topics, or connect the cloud service for open-ended conversations.";
        }
        if(setsunaAnswer!=null)setsunaAnswer.setText(response);
        setsunaSpeak(response);
    }

    private void showSettings(){
        LinearLayout contents=col();contents.setPadding(dp(25),dp(10),dp(25),dp(5));
        CheckBox ai=new CheckBox(this);ai.setText("Enable Setsuna AI and online lookups");
        ai.setTextColor(Color.BLACK);ai.setChecked(isSetsunaEnabled());contents.addView(ai);
        TextView cloudHeader=text("Setsuna online service (requires deployed backend)",14,Color.DKGRAY,true);
        cloudHeader.setPadding(0,dp(12),0,dp(6));contents.addView(cloudHeader);
        EditText cloud=input("HTTPS Cloudflare Worker URL");
        cloud.setText(cloudUrl());contents.addView(cloud,lp(-1,48));
        CheckBox online=new CheckBox(this);
        online.setText("Allow online AI conversations and synthesized voice");
        online.setTextColor(Color.BLACK);
        online.setChecked(prefs.getBoolean("online_setsuna_consent",false));contents.addView(online);
        CheckBox presence=new CheckBox(this);
        presence.setText("Share anonymous presence for online / total counters");
        presence.setTextColor(Color.BLACK);
        presence.setChecked(prefs.getBoolean("anonymous_presence_consent",false));contents.addView(presence);
        TextView privacy=text("Online questions and up to 24 music titles go to the publisher's AI service. Counters use a random anonymous installation ID. The voice is AI-generated, not a person. Online features require a configured free server and are limited by its daily quota.",12,Color.DKGRAY,false);
        contents.addView(privacy);
        TextView colors=text("Theme accent color",14,Color.DKGRAY,true);contents.addView(colors);
        LinearLayout colorsRow=row();
        int[] colorsValue={PURPLE,PINK,Color.rgb(60,168,255),Color.rgb(42,186,133)};
        final int[] newAccent={accent()};
        String[] colorsName={"Purple","Pink","Blue","Green"};
        for(int k=0;k<colorsValue.length;k++){
            final int picked=colorsValue[k];
            Button choice=button(colorsName[k]);choice.setTextSize(10);
            LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(0,dp(41),1);
            colorsRow.addView(choice,cp);
            choice.setOnClickListener(v->{newAccent[0]=picked;toast("Color selected. Tap SAVE to apply.");});
        }
        contents.addView(colorsRow);
        TextView backgroundTitle=text("Background theme",14,Color.DKGRAY,true);
        contents.addView(backgroundTitle);
        LinearLayout themes=row();
        String[] themeNames={"Night","Blue","Slate","Violet"};
        final int[] selectedScheme={prefs.getInt("theme_scheme",0)};
        for(int j=0;j<themeNames.length;j++){
            final int theme=j;
            Button tile=button(themeNames[j]);tile.setTextSize(10);
            themes.addView(tile,new LinearLayout.LayoutParams(0,dp(42),1));
            tile.setOnClickListener(v->{selectedScheme[0]=theme;toast("Theme selected; tap SAVE.");});
        }
        contents.addView(themes);
        CheckBox automatic=new CheckBox(this);
        automatic.setText("Check GitHub for updates when opening the app");
        automatic.setTextColor(Color.BLACK);
        automatic.setChecked(prefs.getBoolean("auto_updates",false));
        contents.addView(automatic);
        CheckBox lockPlayer=new CheckBox(this);
        lockPlayer.setText("Open expanded player when tapping the lock-screen notification");
        lockPlayer.setTextColor(Color.BLACK);
        lockPlayer.setChecked(prefs.getBoolean("lockscreen_expanded",true));
        contents.addView(lockPlayer);
        EditText repository=input("GitHub repository: owner/repo");
        repository.setText(prefs.getString("update_repository",""));
        LinearLayout.LayoutParams repoLp=lp(-1,48);repoLp.topMargin=dp(10);
        contents.addView(repository,repoLp);
        Button check=button("CHECK FOR UPDATES NOW");
        contents.addView(check,lp(-1,46));
        Button install=button("INSTALL ALREADY DOWNLOADED UPDATE");
        contents.addView(install,lp(-1,46));
        String versionName="unknown";
        try {versionName=getPackageManager().getPackageInfo(getPackageName(),0).versionName;}catch(Exception ignored){}
        long currentCode=0;
        try {currentCode=GitHubUpdates.installedVersion(this);}catch(Exception ignored){}
        TextView version=text("Kitsune Beats "+versionName+" (versionCode "+currentCode+")",12,Color.DKGRAY,false);
        version.setPadding(0,dp(12),0,dp(7));contents.addView(version);
        ScrollView settingsScroll=new ScrollView(this);
        settingsScroll.addView(contents);
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("Kitsune Beats Settings")
            .setView(settingsScroll).setPositiveButton("SAVE",(d,w)->{
                prefs.edit().putBoolean("setsuna_enabled",ai.isChecked())
                    .putBoolean("auto_updates",automatic.isChecked())
                    .putString("update_repository",repository.getText().toString().trim())
                    .putString("cloud_service_url",cloud.getText().toString().trim())
                    .putBoolean("online_setsuna_consent",online.isChecked())
                    .putBoolean("anonymous_presence_consent",presence.isChecked())
                    .putBoolean("lockscreen_expanded",lockPlayer.isChecked())
                    .putInt("theme_accent",newAccent[0])
                    .putInt("theme_scheme",selectedScheme[0]).apply();
                if(!ai.isChecked()){
                    if(setsunaTts!=null)setsunaTts.stop();
                    if(setsunaVoice!=null){setsunaVoice.release();setsunaVoice=null;}
                }
                buildInterface();filter("");refreshPlayer();updatePresence();
            }).setNegativeButton("CANCEL",null).create();
        check.setOnClickListener(v->{
            prefs.edit().putString("update_repository",repository.getText().toString().trim()).apply();
            dialog.dismiss();checkForUpdates(true);
        });
        install.setOnClickListener(v->{dialog.dismiss();installDownloadedUpdate();});
        dialog.show();
    }

    private void checkForUpdates(boolean manual) {
        if(updateCheckRunning)return;
        String repo=prefs.getString("update_repository","");
        if(repo.trim().isEmpty()){
            if(manual)toast("Add your GitHub owner/repo in Settings first.");
            return;
        }
        updateCheckRunning=true;
        if(manual)toast("Checking GitHub Releases…");
        work.execute(()->{
            try {
                GitHubUpdates.Release latest=GitHubUpdates.latest(repo);
                long installed=GitHubUpdates.installedVersion(getApplicationContext());
                runOnUiThread(()->{
                    updateCheckRunning=false;
                    if(latest.versionCode<=installed){
                        if(manual)toast("Kitsune Beats is already up to date.");
                        return;
                    }
                    if(isFinishing()||isDestroyed())return;
                    new AlertDialog.Builder(this).setTitle("Kitsune Beats update available")
                        .setMessage("Latest: "+latest.name+" (version code "+latest.versionCode+")\n"+
                            "Installed version code: "+installed+"\n\n"+
                            "Download this newer signed APK? Android will ask for permission before installation.")
                        .setPositiveButton("DOWNLOAD",(d,w)->downloadUpdate(latest))
                        .setNegativeButton("LATER",null).show();
                });
            }catch(Exception e){
                runOnUiThread(()->{updateCheckRunning=false;
                    if(manual && !isFinishing())new AlertDialog.Builder(this).setTitle("Update check failed")
                        .setMessage(e.getMessage()).setPositiveButton("OK",null).show();
                });
            }
        });
    }

    private void downloadUpdate(GitHubUpdates.Release info){
        if(updateDownloadRunning)return;
        updateDownloadRunning=true;
        ProgressDialog progress=new ProgressDialog(this);
        progress.setTitle("Downloading Kitsune Beats update");
        progress.setMessage("Verifying the signed APK before installation…");
        progress.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
        progress.setMax(100);progress.setCancelable(false);progress.show();
        work.execute(()->{
            try {
                GitHubUpdates.downloadAndVerify(getApplicationContext(),info,(done,total)->{
                    int percent=total>0?(int)Math.min(100,done*100/total):0;
                    runOnUiThread(()->{if(progress.isShowing())progress.setProgress(percent);});
                });
                prefs.edit().putLong("downloaded_update_code",info.versionCode).apply();
                runOnUiThread(()->{
                    updateDownloadRunning=false;progress.dismiss();
                    if(!isFinishing()&&!isDestroyed())new AlertDialog.Builder(this)
                        .setTitle("Download verified")
                        .setMessage("The APK checksum, application ID, newer version, and signing certificate have been checked. Install the update using Android's installer now?")
                        .setPositiveButton("INSTALL",(d,w)->installDownloadedUpdate())
                        .setNegativeButton("LATER",null).show();
                });
            }catch(Exception e){runOnUiThread(()->{
                updateDownloadRunning=false;progress.dismiss();
                if(!isFinishing()&&!isDestroyed())new AlertDialog.Builder(this)
                    .setTitle("Update download failed").setMessage(e.getMessage())
                    .setPositiveButton("OK",null).show();
            });}
        });
    }

    private void installDownloadedUpdate() {
        File dir=getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
        File apk=dir==null?null:new File(dir,"kitsune-update.apk");
        long code=prefs.getLong("downloaded_update_code",0L);
        try {
            GitHubUpdates.verifyPackage(this,apk,code);
            if(Build.VERSION.SDK_INT>=26&&!getPackageManager().canRequestPackageInstalls()){
                new AlertDialog.Builder(this).setTitle("Allow APK installation")
                    .setMessage("Android requires your approval to install updates from Kitsune Beats. Enable this source, return to Kitsune Beats, and tap 'INSTALL ALREADY DOWNLOADED UPDATE' in Settings.")
                    .setPositiveButton("OPEN SETTINGS",(d,w)->{
                        Intent intent=new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                            Uri.parse("package:"+getPackageName()));
                        startActivity(intent);
                    }).setNegativeButton("CANCEL",null).show();
                return;
            }
            Intent install=new Intent(Intent.ACTION_INSTALL_PACKAGE);
            install.setDataAndType(GitHubUpdates.shareUri(this),"application/vnd.android.package-archive");
            install.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(install);
        }catch(Exception e){new AlertDialog.Builder(this).setTitle("Cannot install update")
            .setMessage(e.getMessage()).setPositiveButton("OK",null).show();}
    }

    private boolean isShowingGroups(){return libraryMode!=0 && selectedGroup==null;}
    private String groupOf(Song song){
        if(libraryMode==1)return song.folder;
        if(libraryMode==2)return song.artist;
        if(libraryMode==3)return song.genre;
        return "";
    }
    private void filter(String search){
        if(songAdapter==null)return;
        String needle=search.toLowerCase(java.util.Locale.ROOT).trim();
        filtered.clear();groups.clear();
        if(isShowingGroups()){
            Set<String> unique=new java.util.TreeSet<>(String.CASE_INSENSITIVE_ORDER);
            for(Song song:songs) {
                String group=groupOf(song);
                if(needle.isEmpty()||group.toLowerCase(java.util.Locale.ROOT).contains(needle))unique.add(group);
            }
            groups.addAll(unique);
        } else {
            for(Song song:songs){
                if(libraryMode!=0 && (selectedGroup==null||!selectedGroup.equalsIgnoreCase(groupOf(song))))continue;
                if(needle.isEmpty() || (song.title+" "+song.artist+" "+song.album+" "+song.genre)
                        .toLowerCase(java.util.Locale.ROOT).contains(needle)) filtered.add(song);
            }
        }
        if(groupsBack!=null)groupsBack.setVisibility(libraryMode!=0&&selectedGroup!=null?View.VISIBLE:View.GONE);
        songAdapter.notifyDataSetChanged();
    }
    private void playSong(Song song){
        if(song==null)return;
        selected=song;
        List<Song> queue=new ArrayList<>(filtered);
        int index=queue.indexOf(song);
        if(index<0){queue=new ArrayList<>(songs);index=queue.indexOf(song);}
        if(index<0)return;
        startService(new Intent(this,PlaybackService.class));
        if(playback==null){pendingQueue.clear();pendingQueue.addAll(queue);pendingPlay=index;return;}
        playback.playQueue(queue,index);
        refreshPlayer();
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},NOTIFICATION_PERMISSION);
    }
    private void songMenu(Song song){
        new AlertDialog.Builder(this).setTitle(song.title)
            .setItems(new String[]{"Rename in Kitsune Beats","Delete from phone"},(d,which)->{
                if(which==0)renameSong(song);else confirmDelete(song);
            }).setNegativeButton("CANCEL",null).show();
    }
    private void renameSong(Song song){
        EditText field=input("Enter song title");field.setText(song.title);
        new AlertDialog.Builder(this).setTitle("Rename song inside Kitsune Beats")
            .setView(field).setNegativeButton("CANCEL",null)
            .setPositiveButton("SAVE",(d,w)->{
                String title=field.getText().toString().trim();
                if(title.isEmpty()){toast("Song title cannot be empty");return;}
                prefs.edit().putString("renamed_title_"+song.id,title).apply();
                song.title=title;
                Song playing=playback==null?null:playback.current();
                if(playing!=null&&playing.id==song.id){playing.title=title;playback.refreshMetadata();}
                displayedSongId=-1;
                filter(librarySearch.getText().toString());refreshPlayer();
                toast("Display title updated. Original file was not renamed.");
            }).show();
    }
    private void confirmDelete(Song song){
        new AlertDialog.Builder(this).setTitle("Permanently delete this audio file?")
            .setMessage(song.title+"\n\nThis removes the actual file from your phone. This cannot be undone.")
            .setNegativeButton("CANCEL",null)
            .setPositiveButton("DELETE",(d,w)->requestDelete(song)).show();
    }
    private void requestDelete(Song song){
        pendingDeletion=song;
        deleteNeedsRetryOnAndroid10=false;
        if(Build.VERSION.SDK_INT>=30){
            try {
                PendingIntent request=MediaStore.createDeleteRequest(getContentResolver(),
                    Collections.singletonList(song.uri));
                startIntentSenderForResult(request.getIntentSender(),DELETE_REQUEST,null,0,0,0);
            }catch(Exception ex){pendingDeletion=null;toast("Delete request failed: "+ex.getMessage());}
        }else{
            try{
                int removed=getContentResolver().delete(song.uri,null,null);
                if(removed>0)deletedSong(song);else toast("Unable to delete this file");
            }catch(android.app.RecoverableSecurityException recoverable){
                // Android 10 prompts the user to grant delete permission for this one audio file.
                if(Build.VERSION.SDK_INT==29){
                    try {
                        deleteNeedsRetryOnAndroid10=true;
                        startIntentSenderForResult(recoverable.getUserAction().getActionIntent().getIntentSender(),
                                DELETE_REQUEST,null,0,0,0);
                        return;
                    }catch(Exception retryError){toast("Android denied deletion: "+retryError.getMessage());}
                }else toast("Android denied deletion");
            }catch(Exception e){toast("Android denied deletion: "+e.getMessage());}
            pendingDeletion=null;
        }
    }
    @Override protected void onActivityResult(int code,int result,Intent data){
        super.onActivityResult(code,result,data);
        if(code==VOICE_REQUEST){
            if(result==RESULT_OK&&data!=null&&gameSearch!=null){
                ArrayList<String> words=data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                if(words!=null&&!words.isEmpty()){
                    String spoken=words.get(0);
                    if(onlineAssistant()||isQuickHelpCommand(spoken)){
                        if(setsunaQuestion!=null)setsunaQuestion.setText(spoken);
                        answerSetsuna(spoken);
                    }else {gameSearch.setText(spoken);findGame();}
                }
            }
            return;
        }
        if(code==DELETE_REQUEST){
            Song song=pendingDeletion;pendingDeletion=null;
            boolean retry=deleteNeedsRetryOnAndroid10;deleteNeedsRetryOnAndroid10=false;
            if(result!=RESULT_OK||song==null){toast("Deletion cancelled");return;}
            if(retry){
                try{
                    if(getContentResolver().delete(song.uri,null,null)>0)deletedSong(song);
                    else toast("Android did not delete the file");
                }catch(Exception e){toast("Unable to delete file: "+e.getMessage());}
            }else deletedSong(song);
        }
    }
    private void deletedSong(Song song){
        if(playback!=null&&playback.current()!=null&&playback.current().id==song.id)
            playback.stopPlaying();
        prefs.edit().remove("renamed_title_"+song.id).apply();
        songs.removeIf(s->s.id==song.id);
        selected=selected==song?null:selected;
        displayedSongId=-1;filter(librarySearch.getText().toString());
        toast("Audio file deleted from phone");
    }
    private long displayedSongId=-1;
    private void refreshPlayer(){
        if(nowTitle==null)return;
        Song playing=chosen();
        if(playing==null){nowTitle.setText("No song playing");return;}
        if(displayedSongId!=playing.id){
            displayedSongId=playing.id;selected=playing;
            autoEnrich(playing);
            nowTitle.setText(playing.title);nowArtist.setText(playing.artist+" • "+playing.album);
            nowCover.setImageResource(R.drawable.fox_default);
            updateSelected();
            work.execute(()->{
                Bitmap art=Artwork.loadOrExtract(getApplicationContext(),playing);
                if(art!=null)runOnUiThread(()->{
                    if(displayedSongId==playing.id){nowCover.setImageBitmap(art);songAdapter.notifyDataSetChanged();}
                });
            });
        }
        if(playback==null)return;
        toggle.setText(playback.isPlaying()?"PAUSE ❚❚":playback.isPreparing()?"LOADING…":"PLAY ▶");
        shuffle.setText(playback.isShuffle()?"SHUFFLE ✓":"SHUFFLE");
        repeat.setText(playback.repeatMode()==2?"REPEAT 1":playback.repeatMode()==1?"REPEAT ALL":"REPEAT");
        int duration=playback.duration(),at=playback.position();
        if(!seeking)seek.setProgress(duration>0?(int)(1000L*at/duration):0);
        currentTime.setText(fmt(at));totalTime.setText(fmt(duration));
    }

    private void startCoverCheck(List<Song> found){
        if(!isSetsunaEnabled())return;
        metadata.execute(()->{
            Set<String> seen=new HashSet<>();int checks=0;
            for(Song s:found){
                if(Thread.currentThread().isInterrupted()||!isSetsunaEnabled())return;
                String key=s.album.toLowerCase(java.util.Locale.ROOT)+"|"+s.artist.toLowerCase(java.util.Locale.ROOT);
                if(!seen.add(key))continue;
                if(Artwork.loadOrExtract(getApplicationContext(),s)!=null)continue;
                if(s.album.equals("Unknown album")||s.artist.equals("Unknown artist"))continue;
                if(checks++>=20)break; // Free-service rate limits: first 20 missing albums per session.
                try {
                    Bitmap cover=OnlineLookup.albumCover(s);
                    if(cover!=null){
                        for(Song related:found){
                            if(related.album.equalsIgnoreCase(s.album)&&related.artist.equalsIgnoreCase(s.artist)
                                    && Artwork.cached(getApplicationContext(),related)==null)
                                Artwork.save(getApplicationContext(),related,cover);
                        }
                        runOnUiThread(()->{if(songAdapter!=null)songAdapter.notifyDataSetChanged();});
                    }
                    Thread.sleep(1300); // MusicBrainz asks clients not to exceed 1 request per second.
                }catch(InterruptedException e){Thread.currentThread().interrupt();return;}
                catch(Exception ignored){}
            }
        });
    }

    private void findGame(){
        if(!isSetsunaEnabled()){toast("Enable Setsuna AI in Settings");return;}
        if(gameSearch==null)return;
        String query=gameSearch.getText().toString().trim();
        if(query.isEmpty()){toast("Enter a search title.");return;}
        gameResultsContainer.removeAllViews();
        gameResultsContainer.addView(text("Setsuna is searching…",14,PINK,true));
        work.execute(()->{
            try {
                List<OnlineLookup.GameResult> found=OnlineLookup.artworkSearch(query);
                runOnUiThread(()->displayGames(found));
            }catch(Exception e){runOnUiThread(()->{
                gameResultsContainer.removeAllViews();
                gameResultsContainer.addView(text("Could not search right now: "+e.getMessage(),13,MUTED,false));
            });}
        });
    }
    private void displayGames(List<OnlineLookup.GameResult> found){
        gameResults.clear();gameResults.addAll(found);gameResultsContainer.removeAllViews();
        List<OnlineLookup.GameResult> withImages=new ArrayList<>();
        for(OnlineLookup.GameResult game:found)if(game.imageUrl!=null&&!game.imageUrl.isEmpty())withImages.add(game);
        if(withImages.isEmpty()){
            gameResultsContainer.addView(text("No matching artwork found. Try a more specific game, album, or artist title.",13,MUTED,false));return;
        }
        gameResultsContainer.addView(text("Select an artwork match:",14,PINK,true));
        for(OnlineLookup.GameResult game:withImages){
            LinearLayout b=row();b.setBackground(shape(panelColor(),12));b.setPadding(dp(5),dp(5),dp(9),dp(5));
            ImageView thumb=new ImageView(this);thumb.setScaleType(ImageView.ScaleType.CENTER_CROP);
            thumb.setImageResource(R.drawable.fox_default);b.addView(thumb,lp(52,52));
            TextView label=text(game.title,13,WHITE,true);
            label.setPadding(dp(10),0,0,0);
            b.addView(label,new LinearLayout.LayoutParams(0,-2,1));
            LinearLayout.LayoutParams p=lp(-1,64);p.topMargin=dp(8);
            gameResultsContainer.addView(b,p);
            b.setOnClickListener(v->reviewGame(game));
            work.execute(()->{
                try{Bitmap preview=OnlineLookup.image(game.imageUrl);
                    if(preview!=null)runOnUiThread(()->{
                        if(thumb.getParent()!=null)thumb.setImageBitmap(preview);
                    });
                }catch(Exception ignored){}
            });
        }
    }
    private void reviewGame(OnlineLookup.GameResult game){
        Song target=chosen();
        if(target==null){toast("Play or select a song from your library first.");return;}
        LinearLayout content=col();content.setPadding(dp(20),dp(12),dp(20),dp(8));
        ImageView img=new ImageView(this);img.setScaleType(ImageView.ScaleType.FIT_CENTER);
        img.setImageResource(R.drawable.fox_default);
        content.addView(img,lp(-1,210));
        TextView description=text(game.description.isEmpty()?"No detailed game information available.":game.description,13,Color.DKGRAY,false);
        description.setTextColor(Color.DKGRAY);
        content.addView(description);
        if(!game.imageUrl.isEmpty()){
            work.execute(()->{
                try{Bitmap cover=OnlineLookup.image(game.imageUrl);
                    if(cover!=null)runOnUiThread(()->img.setImageBitmap(cover));
                }catch(Exception ignored){}
            });
        }
        AlertDialog.Builder dialog=new AlertDialog.Builder(this)
            .setTitle(game.title).setView(content)
            .setNegativeButton("CANCEL",(d,w)->{})
            .setNeutralButton("ART ONLY",(d,w)->applyGame(target,game,false))
            .setPositiveButton("ART + INFO",(d,w)->applyGame(target,game,true));
        dialog.show();
    }
    private void applyGame(Song target,OnlineLookup.GameResult game,boolean withInfo){
        if(withInfo){prefs.edit().putString("game_title_"+target.id,game.title)
            .putString("game_info_"+target.id,game.description).apply();}
        if(game.imageUrl.isEmpty()){
            toast(withInfo?"Game information saved (no artwork on this result).":"No artwork available for this result.");
            return;
        }
        toast("Downloading artwork over your available connection…");
        work.execute(()->{
            try{
                Bitmap cover=OnlineLookup.image(game.imageUrl);
                if(cover==null)throw new Exception("Image unavailable");
                Artwork.save(getApplicationContext(),target,cover);
                runOnUiThread(()->{
                    if(displayedSongId==target.id)nowCover.setImageBitmap(cover);
                    songAdapter.notifyDataSetChanged();
                    toast("Setsuna applied the artwork"+(withInfo?" and game information.":"."));
                });
            }catch(Exception e){runOnUiThread(()->toast("Artwork failed: "+e.getMessage()));}
        });
    }
    // Automatically cache free lyrics and artist information as each new track begins.
    // These lookups never block playback and work over Wi-Fi or mobile data.
    private void autoEnrich(Song song) {
        if(!isSetsunaEnabled())return;
        work.execute(()->{
            if(savedLyrics(song)==null && !song.artist.equals("Unknown artist")) {
                try {
                    String result=OnlineLookup.lyrics(song);
                    if(!result.startsWith("No lyrics") && !result.isEmpty()) {
                        try(FileOutputStream out=new FileOutputStream(lyricFile(song))) {
                            out.write(result.getBytes(StandardCharsets.UTF_8));
                        }
                    }
                } catch(Exception ignored){}
            }
            String key="artist_"+song.artist.toLowerCase(java.util.Locale.ROOT);
            if(!prefs.contains(key) && !song.artist.equals("Unknown artist")) {
                try {prefs.edit().putString(key,OnlineLookup.artistInfo(song.artist)).apply();}
                catch(Exception ignored){}
            }
        });
    }
    private File lyricFile(Song s){File f=new File(getFilesDir(),"lyrics");if(!f.exists())f.mkdirs();return new File(f,"song_"+s.id+".txt");}
    private String savedLyrics(Song s){
        try(FileInputStream in=new FileInputStream(lyricFile(s))){
            byte[] b=new byte[(int)lyricFile(s).length()];int n=in.read(b);
            return n>0?new String(b,0,n,StandardCharsets.UTF_8):null;
        }catch(Exception e){return null;}
    }
    private void showLyrics(){
        if(!isSetsunaEnabled()){toast("Enable Setsuna AI for lyrics");return;}
        Song s=chosen();if(s==null){toast("Select a song first.");return;}
        String saved=savedLyrics(s);
        if(saved!=null){dialogText("LYRICS — "+s.title,saved);return;}
        toast("Searching for lyrics…");
        work.execute(()->{
            String lyric;
            try {lyric=OnlineLookup.lyrics(s);}
            catch(Exception e){lyric="Could not load lyrics: "+e.getMessage();}
            String finalLyric=lyric;
            if(!lyric.startsWith("Could not")&&!lyric.startsWith("No lyrics")){
                try(FileOutputStream out=new FileOutputStream(lyricFile(s))){out.write(lyric.getBytes(StandardCharsets.UTF_8));}
                catch(Exception ignored){}
            }
            runOnUiThread(()->dialogText("LYRICS — "+s.title,finalLyric));
        });
    }
    private void showArtist(){
        if(!isSetsunaEnabled()){toast("Enable Setsuna AI for artist information");return;}
        Song s=chosen();if(s==null){toast("Select a song first.");return;}
        String gameTitle=prefs.getString("game_title_"+s.id,"");
        String gameInfo=prefs.getString("game_info_"+s.id,"");
        if(!gameTitle.isEmpty()){
            new AlertDialog.Builder(this).setTitle("GAME: "+gameTitle)
                .setMessage(gameInfo+"\n\nArtist: "+s.artist)
                .setPositiveButton("ARTIST BIO",(d,w)->lookupArtist(s)).setNegativeButton("CLOSE",null).show();
        }else lookupArtist(s);
    }
    private void lookupArtist(Song song){
        String key="artist_"+song.artist.toLowerCase(java.util.Locale.ROOT);
        String cached=prefs.getString(key,null);
        if(cached!=null){dialogText("ARTIST INFORMATION",cached);return;}
        toast("Looking up artist information…");
        work.execute(()->{
            String info;
            try{info=OnlineLookup.artistInfo(song.artist);}
            catch(Exception e){info="Artist lookup unavailable: "+e.getMessage();}
            String display=info;
            if(!info.startsWith("Artist lookup unavailable"))prefs.edit().putString(key,info).apply();
            runOnUiThread(()->dialogText("ARTIST INFORMATION",display));
        });
    }
    private void dialogText(String title,String content){
        if(isFinishing()||isDestroyed())return;
        ScrollView scroll=new ScrollView(this);
        TextView txt=text(content,15,Color.DKGRAY,false);
        txt.setPadding(dp(20),dp(12),dp(20),dp(20));scroll.addView(txt);
        new AlertDialog.Builder(this).setTitle(title).setView(scroll)
            .setPositiveButton("CLOSE",null).show();
    }
}
