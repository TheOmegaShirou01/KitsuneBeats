package com.yamanatsuchi.kitsunebeats;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;
import java.io.File;
import java.io.FileNotFoundException;

/** Shares one specifically named downloaded APK with Android's package installer. */
public final class UpdateApkProvider extends ContentProvider {
    private File selected(Uri uri) throws FileNotFoundException {
        if(uri==null||!"update.apk".equals(uri.getLastPathSegment())||
            !"content".equals(uri.getScheme())||
            !getContext().getPackageName().concat(".apkshare").equals(uri.getAuthority()))
            throw new FileNotFoundException("Unknown APK content URI");
        File dir=getContext().getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
        if(dir==null)throw new FileNotFoundException("Download directory unavailable");
        File file=new File(dir,"kitsune-update.apk");
        if(!file.isFile())throw new FileNotFoundException("No verified APK downloaded");
        return file;
    }
    @Override public boolean onCreate(){return true;}
    @Override public String getType(Uri uri){return "application/vnd.android.package-archive";}
    @Override public ParcelFileDescriptor openFile(Uri uri,String mode) throws FileNotFoundException {
        if(!"r".equals(mode))throw new FileNotFoundException("Read-only provider");
        return ParcelFileDescriptor.open(selected(uri),ParcelFileDescriptor.MODE_READ_ONLY);
    }
    @Override public Cursor query(Uri uri,String[] projection,String selection,String[] selectionArgs,String sortOrder){
        try {
            File file=selected(uri);
            String[] columns=projection==null?new String[]{OpenableColumns.DISPLAY_NAME,OpenableColumns.SIZE}:projection;
            MatrixCursor result=new MatrixCursor(columns);
            Object[] values=new Object[columns.length];
            for(int i=0;i<columns.length;i++){
                if(OpenableColumns.DISPLAY_NAME.equals(columns[i]))values[i]="KitsuneBeats-update.apk";
                else if(OpenableColumns.SIZE.equals(columns[i]))values[i]=file.length();
            }
            result.addRow(values);return result;
        }catch(FileNotFoundException e){return null;}
    }
    @Override public Uri insert(Uri uri,ContentValues values){throw new UnsupportedOperationException("Read-only");}
    @Override public int delete(Uri uri,String selection,String[] selectionArgs){throw new UnsupportedOperationException("Read-only");}
    @Override public int update(Uri uri,ContentValues values,String selection,String[] selectionArgs){throw new UnsupportedOperationException("Read-only");}
}
