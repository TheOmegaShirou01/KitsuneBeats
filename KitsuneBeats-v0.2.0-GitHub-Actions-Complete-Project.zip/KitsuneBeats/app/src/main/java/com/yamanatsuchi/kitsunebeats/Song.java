package com.yamanatsuchi.kitsunebeats;

import android.net.Uri;

public final class Song {
    public final long id;
    public String title;
    public final String artist, album, folder, genre;
    public final long duration;
    public final Uri uri;

    public Song(long id, String title, String artist, String album, long duration, Uri uri,
                String folder, String genre) {
        this.id = id;
        this.title = clean(title, "Untitled");
        this.artist = clean(artist, "Unknown artist");
        this.album = clean(album, "Unknown album");
        this.folder = clean(folder, "Other folders");
        this.genre = clean(genre, "Unknown genre");
        this.duration = duration;
        this.uri = uri;
    }

    private static String clean(String s, String fallback) {
        if (s == null || s.trim().isEmpty() || s.equals("<unknown>")) return fallback;
        return s.trim();
    }
}
