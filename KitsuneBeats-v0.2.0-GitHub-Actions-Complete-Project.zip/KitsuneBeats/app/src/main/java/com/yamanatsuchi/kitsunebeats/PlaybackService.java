package com.yamanatsuchi.kitsunebeats;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaMetadata;
import android.media.MediaPlayer;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.os.Binder;
import android.os.Build;
import android.os.IBinder;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.graphics.Bitmap;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class PlaybackService extends Service {
    public static final String ACTION_TOGGLE = "com.yamanatsuchi.kitsunebeats.TOGGLE";
    public static final String ACTION_NEXT = "com.yamanatsuchi.kitsunebeats.NEXT";
    public static final String ACTION_PREV = "com.yamanatsuchi.kitsunebeats.PREV";
    public static final String ACTION_STOP = "com.yamanatsuchi.kitsunebeats.STOP";
    private static final String CHANNEL = "kitsune_music";
    private static final int NOTIFICATION_ID = 1501;

    public final class LocalBinder extends Binder {
        public PlaybackService getService() { return PlaybackService.this; }
    }
    private final IBinder binder = new LocalBinder();
    private final List<Song> queue = new ArrayList<>();
    private final Random rng = new Random();
    private MediaPlayer player;
    private final Handler timelineHandler = new Handler(Looper.getMainLooper());
    private final Runnable timelineUpdate = new Runnable(){
        @Override public void run(){
            if(session!=null){
                if(isPlaying())updateState();
                timelineHandler.postDelayed(this,1200);
            }
        }
    };
    private MediaSession session;
    private AudioManager audioManager;
    private AudioFocusRequest focusRequest;
    private final AudioManager.OnAudioFocusChangeListener focusListener = change -> {
        if (change == AudioManager.AUDIOFOCUS_LOSS || change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) pause();
        else if (player != null && change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK) player.setVolume(.3f,.3f);
        else if (player != null && change == AudioManager.AUDIOFOCUS_GAIN) player.setVolume(1f,1f);
    };
    private int failedTracksInARow=0;
    private int index=-1, repeat=0;
    private boolean shuffle=false, preparing=false, ready=false, foreground=false;

    @Override public void onCreate() {
        super.onCreate();
        audioManager=(AudioManager)getSystemService(AUDIO_SERVICE);
        NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL,"Music playback",NotificationManager.IMPORTANCE_LOW));
        session=new MediaSession(this,"KitsuneBeatsSession");
        session.setFlags(MediaSession.FLAG_HANDLES_MEDIA_BUTTONS|MediaSession.FLAG_HANDLES_TRANSPORT_CONTROLS);
        session.setCallback(new MediaSession.Callback() {
            @Override public void onPlay() {resume();}
            @Override public void onPause() {pause();}
            @Override public void onSkipToNext() {next();}
            @Override public void onSkipToPrevious() {previous();}
            @Override public void onSeekTo(long pos) {seekTo((int)pos);}
            @Override public void onStop() {stopPlaying();}
        });
        session.setActive(true);
        timelineHandler.postDelayed(timelineUpdate,1200);
    }

    @Override public IBinder onBind(Intent intent) {return binder;}

    @Override public int onStartCommand(Intent intent,int flags,int startId) {
        if (intent!=null && intent.getAction()!=null) {
            switch(intent.getAction()) {
                case ACTION_TOGGLE: toggle(); break;
                case ACTION_NEXT: next(); break;
                case ACTION_PREV: previous(); break;
                case ACTION_STOP: stopPlaying(); break;
                default: break;
            }
        }
        return START_STICKY;
    }

    public void playQueue(List<Song> songs,int requested) {
        failedTracksInARow=0;
        queue.clear(); queue.addAll(songs);
        if (!queue.isEmpty()) playAt(Math.max(0,Math.min(requested,queue.size()-1)));
    }
    public Song current() {return index>=0&&index<queue.size()?queue.get(index):null;}
    public boolean isPlaying() {return ready&&player!=null&&player.isPlaying();}
    public boolean isPreparing() {return preparing;}
    public int position() {try {return ready&&player!=null?player.getCurrentPosition():0;}catch(Exception e){return 0;}}
    public int duration() {try {return ready&&player!=null?player.getDuration():(int)(current()==null?0:current().duration);}catch(Exception e){return 0;}}
    public boolean isShuffle() {return shuffle;}
    public int repeatMode() {return repeat;}
    public void setShuffle(boolean enabled) {shuffle=enabled; updateState();}
    public void cycleRepeat() {repeat=(repeat+1)%3; updateState();}

    private boolean requestFocus() {
        AudioAttributes attributes=new AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build();
        focusRequest=new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
            .setAudioAttributes(attributes).setOnAudioFocusChangeListener(focusListener).build();
        return audioManager.requestAudioFocus(focusRequest)==AudioManager.AUDIOFOCUS_REQUEST_GRANTED;
    }

    private void releasePlayer() {
        ready=false; preparing=false;
        if (player!=null) {
            try {player.reset();player.release();}catch(Exception ignored){}
            player=null;
        }
    }

    private void playAt(int n) {
        if (n<0||n>=queue.size())return;
        index=n;
        releasePlayer();
        Song song=current(); if (song==null)return;
        requestFocus();
        try {
            player=new MediaPlayer();
            player.setAudioAttributes(new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());
            player.setWakeMode(getApplicationContext(),PowerManager.PARTIAL_WAKE_LOCK);
            player.setDataSource(this,song.uri);
            player.setOnPreparedListener(mp -> {
                if (player!=mp)return;
                ready=true; preparing=false;failedTracksInARow=0;
                try {mp.start();}catch(Exception ignored){}
                updateState(); updateNotification();
            });
            player.setOnCompletionListener(mp -> { if (repeat==2) {seekTo(0);resume();}else nextInternal(true); });
            player.setOnErrorListener((mp,what,extra)-> {skipBadTrack();return true;});
            preparing=true;
            player.prepareAsync();
            updateState(); updateNotification();
        } catch(Exception e) {releasePlayer();skipBadTrack();}
    }

    public void toggle() {if (isPlaying())pause();else resume();}
    public void resume() {
        if (ready&&player!=null) {
            requestFocus();
            try {player.start();}catch(Exception ignored){}
            updateState();updateNotification();
        } else if (index<0&&!queue.isEmpty()) playAt(0);
    }
    public void pause() {
        if (isPlaying()) {try{player.pause();}catch(Exception ignored){}}
        updateState();updateNotification();
    }
    public void seekTo(int milliseconds) {
        if (ready&&player!=null) {
            try {player.seekTo(Math.max(0,Math.min(milliseconds,player.getDuration())));}catch(Exception ignored){}
            updateState();
        }
    }
    private void skipBadTrack() {
        if(queue.isEmpty()||++failedTracksInARow>=queue.size()){
            stopPlaying();return;
        }
        // Keep the next attempt asynchronous to avoid recursive failures.
        timelineHandler.post(()->nextInternal(true));
    }
    public void next() {failedTracksInARow=0;nextInternal(false);}
    private void nextInternal(boolean automatic) {
        if (queue.isEmpty())return;
        if (automatic && index==queue.size()-1 && repeat==0 && !shuffle) {pause();seekTo(0);return;}
        int nextIndex=shuffle && queue.size()>1?randomOther():((index+1)%queue.size());
        playAt(nextIndex);
    }
    public void previous() {
        if (queue.isEmpty())return;
        if (position()>3000) {seekTo(0);return;}
        playAt((index-1+queue.size())%queue.size());
    }
    private int randomOther() {int n=index;while(n==index)n=rng.nextInt(queue.size());return n;}

    public void refreshMetadata(){updateNotification();}

    private void updateState() {
        if (session==null)return;
        int status=preparing?PlaybackState.STATE_BUFFERING:isPlaying()?PlaybackState.STATE_PLAYING:
            current()==null?PlaybackState.STATE_STOPPED:PlaybackState.STATE_PAUSED;
        long actions=PlaybackState.ACTION_PLAY|PlaybackState.ACTION_PAUSE|PlaybackState.ACTION_PLAY_PAUSE|
            PlaybackState.ACTION_SKIP_TO_NEXT|PlaybackState.ACTION_SKIP_TO_PREVIOUS|PlaybackState.ACTION_SEEK_TO|PlaybackState.ACTION_STOP;
        session.setPlaybackState(new PlaybackState.Builder().setActions(actions)
            .setState(status,position(),isPlaying()?1f:0f).build());
    }

    private PendingIntent action(String command,int requestCode) {
        Intent i=new Intent(this,PlaybackService.class).setAction(command);
        return PendingIntent.getService(this,requestCode,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    }

    private void updateNotification() {
        Song song=current();if (song==null)return;
        Bitmap cover=Artwork.cached(this,song);
        MediaMetadata.Builder meta=new MediaMetadata.Builder()
            .putString(MediaMetadata.METADATA_KEY_TITLE,song.title)
            .putString(MediaMetadata.METADATA_KEY_ARTIST,song.artist)
            .putString(MediaMetadata.METADATA_KEY_ALBUM,song.album)
            .putLong(MediaMetadata.METADATA_KEY_DURATION,duration());
        if (cover!=null) meta.putBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART,cover);
        session.setMetadata(meta.build());
        boolean expanded=getSharedPreferences("kitsune_library",MODE_PRIVATE)
            .getBoolean("lockscreen_expanded",true);
        Intent launch=new Intent(this,expanded?LockScreenPlayerActivity.class:MainActivity.class)
            .setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP|Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent open=PendingIntent.getActivity(this,21,launch,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification.Action prev=new Notification.Action.Builder(android.R.drawable.ic_media_previous,"Previous",action(ACTION_PREV,1)).build();
        Notification.Action play=new Notification.Action.Builder(isPlaying()?android.R.drawable.ic_media_pause:android.R.drawable.ic_media_play,
            isPlaying()?"Pause":"Play",action(ACTION_TOGGLE,2)).build();
        Notification.Action next=new Notification.Action.Builder(android.R.drawable.ic_media_next,"Next",action(ACTION_NEXT,3)).build();
        Notification.Builder b=new Notification.Builder(this,CHANNEL)
            .setSmallIcon(android.R.drawable.ic_media_play).setContentTitle(song.title)
            .setContentText(song.artist).setContentIntent(open).setOnlyAlertOnce(true)
            .setVisibility(Notification.VISIBILITY_PUBLIC).setOngoing(isPlaying())
            .addAction(prev).addAction(play).addAction(next)
            .setStyle(new Notification.MediaStyle().setMediaSession(session.getSessionToken()).setShowActionsInCompactView(0,1,2));
        if (cover!=null)b.setLargeIcon(cover);
        Notification notification=b.build();
        try {
            if (!foreground) {startForeground(NOTIFICATION_ID,notification);foreground=true;}
            else ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(NOTIFICATION_ID,notification);
        } catch(Exception ignored) {}
    }

    public void stopPlaying() {
        releasePlayer();queue.clear();index=-1;
        if (focusRequest!=null) audioManager.abandonAudioFocusRequest(focusRequest);
        updateState();
        if (foreground) {stopForeground(STOP_FOREGROUND_REMOVE);foreground=false;}
        stopSelf();
    }

    @Override public void onDestroy() {
        timelineHandler.removeCallbacks(timelineUpdate);
        releasePlayer();
        if (session!=null) {session.setActive(false);session.release();session=null;}
        if (focusRequest!=null)audioManager.abandonAudioFocusRequest(focusRequest);
        super.onDestroy();
    }
}
