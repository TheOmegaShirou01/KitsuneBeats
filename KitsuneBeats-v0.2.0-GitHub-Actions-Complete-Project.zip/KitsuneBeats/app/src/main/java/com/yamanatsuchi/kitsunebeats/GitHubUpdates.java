package com.yamanatsuchi.kitsunebeats;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** GitHub Releases public-repository updater; never installs silently. */
public final class GitHubUpdates {
    private GitHubUpdates() {}
    private static final long MAX_APK_BYTES = 180L * 1024 * 1024;
    private static final Pattern REPO = Pattern.compile("[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+");
    private static final Pattern RELEASE_CODE = Pattern.compile("(?im)^\\s*KITSUNE_VERSION_CODE\\s*[:=]\\s*(\\d+)\\s*$");
    public interface Progress { void onBytes(long received, long expected); }
    public static final class Release {
        public final int versionCode;
        public final String name, assetUrl, sha256;
        public final long size;
        Release(int code, String name, String assetUrl, long size, String sha256) {
            this.versionCode=code;this.name=name;this.assetUrl=assetUrl;this.size=size;this.sha256=sha256;
        }
    }
    public static String repoOrThrow(String value) {
        String repo=value == null?"":value.trim();
        if (!REPO.matcher(repo).matches() || repo.contains("..") || repo.startsWith("."))
            throw new IllegalArgumentException("Enter a GitHub repository as owner/repo.");
        return repo;
    }
    public static long installedVersion(Context context) throws Exception {
        PackageInfo info=context.getPackageManager().getPackageInfo(context.getPackageName(),0);
        return android.os.Build.VERSION.SDK_INT>=28?info.getLongVersionCode():info.versionCode;
    }
    public static Release latest(String userRepo) throws Exception {
        String repo=repoOrThrow(userRepo);
        URL url=new URL("https://api.github.com/repos/"+repo+"/releases/latest");
        HttpURLConnection conn=(HttpURLConnection)url.openConnection();
        conn.setConnectTimeout(10000);conn.setReadTimeout(15000);
        conn.setRequestProperty("Accept","application/vnd.github+json");
        conn.setRequestProperty("User-Agent","KitsuneBeats-Android-Updater");
        try {
            if(conn.getResponseCode()!=200)throw new Exception("GitHub Releases unavailable (HTTP "+conn.getResponseCode()+"). Check that the repository and release are public.");
            StringBuilder sb=new StringBuilder();
            try(InputStream in=conn.getInputStream();BufferedReader reader=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8))){
                String line;while((line=reader.readLine())!=null){sb.append(line);if(sb.length()>1_000_000)throw new Exception("Release metadata too large");}
            }
            JSONObject result=new JSONObject(sb.toString());
            Matcher code=RELEASE_CODE.matcher(result.optString("body",""));
            if(!code.find())throw new Exception("Release notes must include KITSUNE_VERSION_CODE=<integer> on its own line.");
            int number=Integer.parseInt(code.group(1));
            if(number<=0)throw new Exception("Invalid release version code");
            JSONArray assets=result.optJSONArray("assets");
            if(assets==null)throw new Exception("Release has no APK asset");
            for(int i=0;i<assets.length();i++){
                JSONObject asset=assets.optJSONObject(i);if(asset==null)continue;
                String name=asset.optString("name","");
                String link=asset.optString("browser_download_url","");
                long size=asset.optLong("size",0);
                String expectedPrefix="https://github.com/"+repo+"/releases/download/";
                if(!name.toLowerCase(Locale.ROOT).endsWith(".apk")||!link.toLowerCase(Locale.ROOT).startsWith(expectedPrefix.toLowerCase(Locale.ROOT))||size<=0||size>MAX_APK_BYTES)continue;
                // GitHub computes a digest of the release asset. Validate it before install.
                String digest=asset.optString("digest","");
                if(!digest.matches("(?i)sha256:[0-9a-f]{64}"))throw new Exception("APK asset must have a GitHub SHA-256 digest.");
                return new Release(number,result.optString("name",result.optString("tag_name","New release")),link,size,digest.substring(7));
            }
            throw new Exception("No suitable APK asset was found in the latest GitHub release.");
        } finally {conn.disconnect();}
    }
    /** Download to app private external files, verify hash, package, higher code and same signer. */
    public static File downloadAndVerify(Context context, Release release, Progress progress) throws Exception {
        File folder=context.getExternalFilesDir(android.os.Environment.DIRECTORY_DOWNLOADS);
        if(folder==null||(!folder.exists()&&!folder.mkdirs()))throw new Exception("Cannot open app download folder");
        File temporary=new File(folder,"kitsune-update.partial.apk");
        File ready=new File(folder,"kitsune-update.apk");
        temporary.delete();
        URL url=new URL(release.assetUrl);
        HttpURLConnection conn=(HttpURLConnection)url.openConnection();
        conn.setConnectTimeout(15000);conn.setReadTimeout(30000);conn.setInstanceFollowRedirects(true);
        conn.setRequestProperty("User-Agent","KitsuneBeats-Android-Updater");
        MessageDigest md=MessageDigest.getInstance("SHA-256");
        long count=0;
        try {
            if(conn.getResponseCode()!=200)throw new Exception("APK download returned HTTP "+conn.getResponseCode());
            if(!"https".equalsIgnoreCase(conn.getURL().getProtocol()))throw new Exception("Insecure APK download redirect blocked");
            try(InputStream in=conn.getInputStream();FileOutputStream out=new FileOutputStream(temporary)) {
                byte[] buffer=new byte[16384];int read;
                while((read=in.read(buffer))!=-1){
                    count+=read;
                    if(count>MAX_APK_BYTES)throw new Exception("APK exceeds maximum download size");
                    md.update(buffer,0,read);out.write(buffer,0,read);
                    if(progress!=null)progress.onBytes(count,release.size);
                }
                out.getFD().sync();
            }
            if(count!=release.size)throw new Exception("Incomplete APK download");
            StringBuilder actual=new StringBuilder();for(byte b:md.digest())actual.append(String.format(Locale.ROOT,"%02x",b&255));
            if(!actual.toString().equalsIgnoreCase(release.sha256))throw new Exception("APK download checksum does not match GitHub");
            verifyPackage(context,temporary,release.versionCode);
            if(ready.exists()&&!ready.delete())throw new Exception("Cannot remove previous downloaded update");
            if(!temporary.renameTo(ready))throw new Exception("Cannot store the downloaded APK");
            return ready;
        } finally {conn.disconnect();if(temporary.exists())temporary.delete();}
    }
    public static void verifyPackage(Context context, File file, long expectedCode) throws Exception {
        if(file==null||!file.isFile())throw new Exception("APK file not found");
        PackageManager pm=context.getPackageManager();
        int flags=android.os.Build.VERSION.SDK_INT>=28 ? PackageManager.GET_SIGNING_CERTIFICATES : PackageManager.GET_SIGNATURES;
        PackageInfo archive=pm.getPackageArchiveInfo(file.getAbsolutePath(),flags);
        if(archive==null||!context.getPackageName().equals(archive.packageName))throw new Exception("APK has a different application ID");
        long archiveCode=android.os.Build.VERSION.SDK_INT>=28?archive.getLongVersionCode():archive.versionCode;
        if(archiveCode<=installedVersion(context)||archiveCode!=expectedCode)throw new Exception("APK version is not newer or does not match release metadata");
        PackageInfo existing=pm.getPackageInfo(context.getPackageName(),flags);
        android.content.pm.Signature[] oldSigners=android.os.Build.VERSION.SDK_INT>=28
                ?existing.signingInfo.getApkContentsSigners():existing.signatures;
        android.content.pm.Signature[] newSigners=android.os.Build.VERSION.SDK_INT>=28
                ?archive.signingInfo.getApkContentsSigners():archive.signatures;
        if(oldSigners==null||newSigners==null||oldSigners.length!=1||newSigners.length!=1||
                !Arrays.equals(oldSigners[0].toByteArray(),newSigners[0].toByteArray()))
            throw new Exception("APK signing key does not match the installed Kitsune Beats app");
    }
    public static Uri shareUri(Context context) {
        return new Uri.Builder().scheme("content")
            .authority(context.getPackageName()+".apkshare").appendPath("update.apk").build();
    }
}
