package com.yamanatsuchi.kitsunebeats;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public final class OnlineLookup {
    private OnlineLookup() {}
    public static class GameResult {
        public final String title, description, imageUrl;
        GameResult(String title, String description, String imageUrl) {
            this.title=title; this.description=description; this.imageUrl=imageUrl;
        }
    }

    private static HttpURLConnection connect(String url) throws Exception {
        HttpURLConnection conn=(HttpURLConnection)new URL(url).openConnection();
        conn.setConnectTimeout(12000);
        conn.setReadTimeout(16000);
        conn.setInstanceFollowRedirects(true);
        conn.setRequestProperty("User-Agent", "KitsuneBeats/0.2-dev (personal noncommercial Android music player)");
        return conn;
    }

    public static String text(String url) throws Exception {
        HttpURLConnection c=connect(url);
        try (InputStream in=c.getInputStream(); BufferedReader br=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8))) {
            StringBuilder sb=new StringBuilder(); String line;
            while ((line=br.readLine())!=null) {
                sb.append(line);
                if (sb.length()>1_500_000) throw new Exception("Response too large");
            }
            return sb.toString();
        } finally {c.disconnect();}
    }

    public static Bitmap image(String url) throws Exception {
        if (url==null || !url.startsWith("https://")) return null;
        HttpURLConnection c=connect(url);
        try (InputStream in=c.getInputStream(); ByteArrayOutputStream out=new ByteArrayOutputStream()) {
            byte[] buf=new byte[8192]; int n;
            while ((n=in.read(buf))!=-1) {
                out.write(buf,0,n);
                if (out.size()>8_000_000) throw new Exception("Image too large");
            }
            byte[] bytes=out.toByteArray();
            BitmapFactory.Options options=new BitmapFactory.Options(); options.inSampleSize=1;
            return BitmapFactory.decodeByteArray(bytes,0,bytes.length,options);
        } finally {c.disconnect();}
    }

    public static List<GameResult> games(String query) throws Exception {
        String term=query.trim();
        if (term.isEmpty()) throw new Exception("Enter a game title first.");
        String endpoint="https://en.wikipedia.org/w/api.php?action=query&generator=search&gsrlimit=8"+
                "&gsrsearch="+Uri.encode(term+" video game")+
                "&prop=extracts%7Cpageimages&exintro=1&explaintext=1&exsentences=4"+
                "&piprop=thumbnail&pithumbsize=700&format=json";
        JSONObject json=new JSONObject(text(endpoint));
        JSONObject pages=json.optJSONObject("query");
        List<GameResult> result=new ArrayList<>();
        if (pages==null) return result;
        JSONObject items=pages.optJSONObject("pages");
        if (items==null) return result;
        JSONArray names=items.names(); if (names==null) return result;
        for (int i=0;i<names.length();i++) {
            JSONObject page=items.optJSONObject(names.optString(i));
            if (page==null) continue;
            JSONObject thumb=page.optJSONObject("thumbnail");
            String image=thumb==null?"":thumb.optString("source","");
            result.add(new GameResult(page.optString("title"),page.optString("extract",""),image));
        }
        return result;
    }

    // Artwork from public album metadata plus Wikipedia game results.
    // No Google Images scraping or user API keys needed for this preview.
    public static List<GameResult> artworkSearch(String query) throws Exception {
        String term=query == null ? "" : query.trim();
        if(term.isEmpty())throw new Exception("Enter an album, artist, or game title.");
        List<GameResult> result=new ArrayList<>();
        Exception error=null;
        try {
            // Search both albums and individual tracks to cover singles and all music genres.
            java.util.HashSet<String> seen=new java.util.HashSet<>();
            for(String entity:new String[]{"album","song"}){
                String api="https://itunes.apple.com/search?term="+Uri.encode(term)+
                        "&entity="+entity+"&limit=15";
                JSONObject data=new JSONObject(text(api));
                JSONArray items=data.optJSONArray("results");
                if(items==null)continue;
                for(int i=0;i<items.length();i++){
                    JSONObject hit=items.optJSONObject(i);
                    if(hit==null)continue;
                    String image=hit.optString("artworkUrl100","");
                    if(!image.startsWith("https://"))continue;
                    image=image.replace("100x100bb","600x600bb");
                    String album=hit.optString("collectionName","");
                    String song=hit.optString("trackName","");
                    String artist=hit.optString("artistName","Unknown artist");
                    String title=entity.equals("song")&& !song.isEmpty()?song:album;
                    if(title.isEmpty()||!seen.add(artist+"|"+title+"|"+album))continue;
                    String info="Artist: "+artist+"\\nAlbum: "+album+
                        (song.isEmpty()?"":"\\nTrack: "+song)+"\\nSource: Apple Music catalog";
                    result.add(new GameResult(artist+" — "+title,info,image));
                }
            }
        } catch(Exception e){error=e;}
        try {
            // Wikipedia helps with regional game covers not always in music stores.
            for(GameResult game:games(term)){
                if(game.imageUrl!=null&&!game.imageUrl.isEmpty())result.add(game);
            }
        }catch(Exception e){if(error==null)error=e;}
        if(result.isEmpty()&&error!=null)throw error;
        return result;
    }

    public static String lyrics(Song song) throws Exception {
        String endpoint="https://lrclib.net/api/search?track_name="+Uri.encode(song.title)+
                "&artist_name="+Uri.encode(song.artist);
        JSONArray list=new JSONArray(text(endpoint));
        if (list.length()==0) return "No lyrics were found for this recording.";
        JSONObject best=list.optJSONObject(0);
        if (best==null) return "No lyrics were found.";
        String plain=best.optString("plainLyrics","");
        if (!plain.isEmpty() && !plain.equals("null")) return plain;
        String timed=best.optString("syncedLyrics","");
        if (timed.isEmpty() || timed.equals("null")) return "No lyrics were found.";
        return timed.replaceAll("(?m)^\\[\\d{2}:\\d{2}\\.\\d{2,3}\\]\\s*", "");
    }

    public static String artistInfo(String artist) throws Exception {
        if (artist==null || artist.equalsIgnoreCase("Unknown artist")) return "No known artist is tagged on this file.";
        String endpoint="https://en.wikipedia.org/w/api.php?action=query&generator=search&gsrlimit=1"+
                "&gsrsearch="+Uri.encode(artist+" musician")+
                "&prop=extracts&exintro=1&explaintext=1&exsentences=8&format=json";
        JSONObject json=new JSONObject(text(endpoint));
        JSONObject q=json.optJSONObject("query"); if (q==null) return "No artist biography found.";
        JSONObject pages=q.optJSONObject("pages"); if (pages==null) return "No artist biography found.";
        JSONArray keys=pages.names(); if (keys==null || keys.length()==0) return "No artist biography found.";
        JSONObject page=pages.optJSONObject(keys.optString(0));
        return page==null ? "No biography found." :
            page.optString("title")+"\n\n"+page.optString("extract","No biography found.");
    }

    public static Bitmap albumCover(Song song) throws Exception {
        if (song.album.equals("Unknown album") || song.artist.equals("Unknown artist")) return null;
        String query="releasegroup:\""+song.album.replace("\"", "")+"\" AND artist:\""+song.artist.replace("\"", "")+"\"";
        String endpoint="https://musicbrainz.org/ws/2/release-group/?query="+Uri.encode(query)+"&fmt=json&limit=1";
        JSONObject search=new JSONObject(text(endpoint));
        JSONArray groups=search.optJSONArray("release-groups");
        if (groups==null || groups.length()==0) return null;
        JSONObject first=groups.optJSONObject(0);
        if (first==null || first.optDouble("score",0)<80) return null;
        String id=first.optString("id","");
        if (id.isEmpty()) return null;
        try { return image("https://coverartarchive.org/release-group/"+id+"/front-500"); }
        catch (Exception e) {return null;}
    }
}
