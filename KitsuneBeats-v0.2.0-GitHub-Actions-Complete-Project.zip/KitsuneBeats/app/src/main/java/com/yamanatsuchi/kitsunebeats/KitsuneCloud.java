package com.yamanatsuchi.kitsunebeats;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.List;

/** Publisher-hosted AI and presence. No vendor API key in the Android application. */
public final class KitsuneCloud {
    private KitsuneCloud() {}
    private static HttpURLConnection connection(String base,String route) throws Exception {
        if(base==null || !base.trim().startsWith("https://"))
            throw new Exception("Configure an HTTPS service URL in Settings.");
        URL u=new URL(base.trim());
        if(u.getHost().isEmpty()||u.getUserInfo()!=null||u.getQuery()!=null||u.getRef()!=null)
            throw new Exception("Invalid cloud URL");
        HttpURLConnection c=(HttpURLConnection)new URL(base.trim().replaceAll("/+$","")+route).openConnection();
        c.setConnectTimeout(12000);
        c.setReadTimeout(25000);
        c.setRequestProperty("User-Agent","KitsuneBeats/0.2.0");
        return c;
    }
    private static byte[] read(InputStream src,int max) throws Exception {
        try(InputStream in=src;ByteArrayOutputStream buf=new ByteArrayOutputStream()){
            byte[] tmp=new byte[8192];int n;
            while((n=in.read(tmp))!=-1){buf.write(tmp,0,n);if(buf.size()>max)throw new Exception("Response too large");}
            return buf.toByteArray();
        }
    }
    private static HttpURLConnection post(String base,String endpoint,JSONObject data) throws Exception {
        HttpURLConnection c=connection(base,endpoint);
        c.setRequestMethod("POST");c.setDoOutput(true);
        c.setRequestProperty("Content-Type","application/json; charset=utf-8");
        byte[] bytes=data.toString().getBytes(StandardCharsets.UTF_8);
        if(bytes.length>12000)throw new Exception("Request too large");
        c.setFixedLengthStreamingMode(bytes.length);
        try(OutputStream out=c.getOutputStream()){out.write(bytes);}
        return c;
    }
    private static JSONObject result(HttpURLConnection c) throws Exception {
        try {
            int status=c.getResponseCode();
            InputStream in=status>=400?c.getErrorStream():c.getInputStream();
            if(in==null)throw new Exception("Cloud unavailable ("+status+")");
            JSONObject body=new JSONObject(new String(read(in,250000),StandardCharsets.UTF_8));
            if(status>=400)throw new Exception(body.optString("error","Cloud unavailable ("+status+")"));
            return body;
        }finally{c.disconnect();}
    }
    public static String answer(String base,String question,List<Song> songs) throws Exception {
        JSONObject req=new JSONObject();req.put("message",question);
        JSONArray library=new JSONArray();
        for(int i=0;i<songs.size()&&i<24;i++){
            Song s=songs.get(i);library.put(s.title+" — "+s.artist+" ["+s.genre+"]");
        }
        req.put("library",library);
        return result(post(base,"/v1/chat",req)).optString("reply","");
    }
    public static JSONObject presence(String base,String uuid) throws Exception {
        JSONObject req=new JSONObject();req.put("installationId",uuid);
        return result(post(base,"/v1/presence",req));
    }
    public static File speech(Context ctx,String base,String text) throws Exception {
        JSONObject req=new JSONObject();req.put("text",text.length()>1000?text.substring(0,1000):text);
        HttpURLConnection c=post(base,"/v1/speech",req);
        try {
            int status=c.getResponseCode();
            if(status!=200){
                InputStream err=c.getErrorStream();
                throw new Exception(err==null?"Voice unavailable ("+status+")":
                    new JSONObject(new String(read(err,10000),StandardCharsets.UTF_8)).optString("error","Voice unavailable"));
            }
            File f=File.createTempFile("setsuna-cloud-", ".mp3", ctx.getCacheDir());
            try(FileOutputStream out=new FileOutputStream(f)){out.write(read(c.getInputStream(),4_000_000));}
            catch(Exception ex){f.delete();throw ex;}
            return f;
        }finally{c.disconnect();}
    }
}
