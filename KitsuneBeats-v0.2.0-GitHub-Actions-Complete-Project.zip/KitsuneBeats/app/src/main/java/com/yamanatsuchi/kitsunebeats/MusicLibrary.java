package com.yamanatsuchi.kitsunebeats;

import android.content.ContentUris;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;
import java.util.ArrayList;
import java.util.List;

public final class MusicLibrary {
    private MusicLibrary() {}

    public static List<Song> scan(Context context) {
        List<Song> result = new ArrayList<>();
        Uri base = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        String[] columns = {
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.DURATION,
            Build.VERSION.SDK_INT >= 29 ? MediaStore.Audio.Media.RELATIVE_PATH : MediaStore.Audio.Media.DATA,
            Build.VERSION.SDK_INT >= 30 ? MediaStore.Audio.Media.GENRE : MediaStore.Audio.Media.TITLE
        };
        try (Cursor c = context.getContentResolver().query(base, columns,
                MediaStore.Audio.Media.DURATION + ">=1000", null,
                MediaStore.Audio.Media.TITLE + " COLLATE NOCASE ASC")) {
            if (c != null) while (c.moveToNext()) {
                long id = c.getLong(0);
                String path = c.getString(5);
                String folder = "Other folders";
                if (path != null && !path.isEmpty()) {
                    if (Build.VERSION.SDK_INT < 29) {
                        int slash = path.lastIndexOf('/');
                        path = slash < 0 ? "" : path.substring(0, slash);
                    }
                    folder = path.replaceAll("/+$", "").trim();
                    if (folder.isEmpty()) folder = "Other folders";
                }
                String genre = "Unknown genre";
                // Genre access through GENRE is supported on Android 11+ (API 30).
                if (Build.VERSION.SDK_INT >= 30) {
                    String storedGenre = c.getString(6);
                    if (storedGenre != null && !storedGenre.trim().isEmpty()) genre = storedGenre;
                } else {
                    try (Cursor g = context.getContentResolver().query(
                            MediaStore.Audio.Genres.getContentUriForAudioId("external", (int)id),
                            new String[]{MediaStore.Audio.Genres.NAME}, null, null, null)) {
                        if (g != null && g.moveToFirst() && g.getString(0) != null
                                && !g.getString(0).trim().isEmpty()) genre = g.getString(0);
                    } catch(Exception ignored) { }
                }
                result.add(new Song(id, c.getString(1), c.getString(2), c.getString(3),
                        c.getLong(4), ContentUris.withAppendedId(base, id), folder, genre));
            }
        }
        return result;
    }
}
