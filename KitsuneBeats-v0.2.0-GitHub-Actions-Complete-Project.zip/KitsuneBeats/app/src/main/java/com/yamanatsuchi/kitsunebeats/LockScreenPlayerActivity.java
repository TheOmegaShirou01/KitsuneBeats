package com.yamanatsuchi.kitsunebeats;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

/**
 * Optional player opened by tapping the notification.
 * Does NOT bypass Android's secure lock screen. OS media controls remain the default.
 */
public final class LockScreenPlayerActivity extends Activity {
    private PlaybackService playback;
    private boolean bound=false, dragging=false;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private TextView title,artist,timing;
    private ImageView cover;
    private SeekBar seek;
    private Button toggle;
    private long shown=-1L;
    private float downY;
    private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}
    private TextView label(String value,int size){
        TextView t=new TextView(this);
        t.setText(value);t.setTextSize(size);t.setTextColor(Color.WHITE);t.setGravity(Gravity.CENTER);
        return t;
    }
    private Button control(String value){
        Button b=new Button(this);b.setText(value);b.setTextColor(Color.WHITE);
        b.setAllCaps(false);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xff342e59));return b;
    }
    private final ServiceConnection con=new ServiceConnection(){
        @Override public void onServiceConnected(ComponentName name,IBinder binder){
            playback=((PlaybackService.LocalBinder)binder).getService();refresh();
        }
        @Override public void onServiceDisconnected(ComponentName name){playback=null;}
    };
    private final Runnable ticker=new Runnable(){
        @Override public void run(){refresh();handler.postDelayed(this,750);}
    };
    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        if(Build.VERSION.SDK_INT>=27)setShowWhenLocked(true);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().setNavigationBarColor(Color.BLACK);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);root.setBackgroundColor(0xff101126);
        root.setPadding(dp(24),dp(12),dp(24),dp(20));
        TextView hint=label("KITSUNE BEATS  •  SWIPE UP TO CLOSE",12);root.addView(hint);
        cover=new ImageView(this);cover.setScaleType(ImageView.ScaleType.FIT_CENTER);
        cover.setImageResource(R.drawable.fox_default);
        LinearLayout.LayoutParams image=new LinearLayout.LayoutParams(-1,0,1);
        image.topMargin=dp(15);image.bottomMargin=dp(18);root.addView(cover,image);
        title=label("No song playing",23);root.addView(title);
        artist=label("",15);root.addView(artist);
        seek=new SeekBar(this);root.addView(seek,new LinearLayout.LayoutParams(-1,dp(48)));
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            @Override public void onStartTrackingTouch(SeekBar b){dragging=true;}
            @Override public void onStopTrackingTouch(SeekBar b){
                if(playback!=null)playback.seekTo((int)(playback.duration()*b.getProgress()/1000L));
                dragging=false;
            }
            @Override public void onProgressChanged(SeekBar b,int v,boolean fromUser){}
        });
        timing=label("0:00 / 0:00",13);root.addView(timing);
        LinearLayout buttons=new LinearLayout(this);buttons.setGravity(Gravity.CENTER);
        Button previous=control("◀◀");toggle=control("▶ / ❚❚");Button next=control("▶▶");
        for(Button b:new Button[]{previous,toggle,next})
            buttons.addView(b,new LinearLayout.LayoutParams(0,dp(58),1));
        root.addView(buttons);
        previous.setOnClickListener(v->{if(playback!=null)playback.previous();refresh();});
        toggle.setOnClickListener(v->{if(playback!=null)playback.toggle();refresh();});
        next.setOnClickListener(v->{if(playback!=null)playback.next();refresh();});
        Button close=control("CLOSE PLAYER");root.addView(close);
        close.setOnClickListener(v->finish());
        setContentView(root);
    }
    private String fmt(int duration){
        long s=Math.max(0,duration/1000);
        return (s/60)+":"+String.format(java.util.Locale.US,"%02d",s%60);
    }
    private void refresh(){
        if(playback==null || playback.current()==null)return;
        Song song=playback.current();
        title.setText(song.title);artist.setText(song.artist);
        toggle.setText(playback.isPlaying()?"❚❚":"▶");
        int d=playback.duration(),at=playback.position();
        if(!dragging)seek.setProgress(d>0?(int)(1000L*at/d):0);
        timing.setText(fmt(at)+" / "+fmt(d));
        if(shown!=song.id){
            shown=song.id;
            Bitmap art=Artwork.cached(this,song);
            if(art!=null)cover.setImageBitmap(art);
            else cover.setImageResource(R.drawable.fox_default);
        }
    }
    @Override protected void onStart(){
        super.onStart();
        bound=bindService(new Intent(this,PlaybackService.class),con,Context.BIND_AUTO_CREATE);
        handler.post(ticker);
    }
    @Override protected void onStop(){
        handler.removeCallbacks(ticker);
        if(bound){unbindService(con);bound=false;}
        playback=null;super.onStop();
    }
    @Override public boolean dispatchTouchEvent(MotionEvent event){
        if(event.getAction()==MotionEvent.ACTION_DOWN)downY=event.getY();
        if(event.getAction()==MotionEvent.ACTION_UP && downY-event.getY()>dp(145)){finish();return true;}
        return super.dispatchTouchEvent(event);
    }
}
