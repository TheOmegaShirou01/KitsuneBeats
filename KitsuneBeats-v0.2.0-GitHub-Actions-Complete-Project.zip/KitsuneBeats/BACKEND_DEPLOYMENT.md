# Kitsune Beats: Online Setsuna and user-counter service

The Android app's **HTTPS cloud URL** is configurable in Settings, so the APK does not contain an API-provider key or a hardcoded account. The server code in `backend/` is a deployable Cloudflare Workers + D1 example, **not a deployed service**.

## Deploy when ready (requires your own accounts)

1. Deploy the optional Worker from a Cloudflare account. If you want to do the setup in a Google Colab terminal, install Node.js 20+ there and authenticate Wrangler using a **private API token** in the runtime, not in source code. Do not paste tokens in ChatGPT.
2. Run `npx wrangler d1 create kitsune-beats-db` from `backend/`. Copy the returned database UUID into a copy of `wrangler.toml.example` named `wrangler.toml`.
3. Run `npx wrangler d1 migrations apply kitsune-beats-db --remote`.
4. Keep the `[ai]` binding in `wrangler.toml` (already in the example). It connects to Cloudflare Workers AI on the **Free** plan; no OpenAI key or billing credentials are needed.
5. Add a randomly generated server-only secret: `npx wrangler secret put RATE_LIMIT_SALT`.
6. Deploy: `npx wrangler deploy`. Keep the account on its Free plan, without upgrading to Paid. Once its free allowance runs out, online chat or speech will become unavailable until the quota resets; it should not generate pay-as-you-go charges.
7. Test the returned `https://...workers.dev/health` and `/v1/stats` endpoints.
8. On your Android device, open Kitsune Beats **Settings**, enter the HTTPS Worker URL, then explicitly enable **online AI and voice**, **presence**, or both.

The backend calls the free-allocation Workers AI binding for chat (`@cf/zai-org/glm-4.7-flash`) and speech (`@cf/myshell-ai/melotts`). A specific cute Japanese anime-girl voice **cannot be guaranteed** using that free TTS model; the Android app has a device TTS fallback. The free tier has daily usage limits, and exhausted requests will fail gracefully. The default English voice is not a custom character performance.

**Privacy and cost:** No paid OpenAI API key is used. This does not deploy itself: a free Cloudflare account, Worker, and D1 database must be created by the owner. The app sends user questions plus up to 24 song titles to the backend only when opted in; presence registers a pseudonymous random installation ID. Never commit secrets, put private keys in chat, or upgrade to a paid plan without deciding to accept potential charges. Anonymous public endpoints require rate limits; limit who can use the service if hosting costs become a concern.

The cloud worker has per-IP hourly counters and input-size limits, but those are **not** a complete anti-abuse system. The app displays unavailable counts rather than fabricated totals while disconnected.

## Verify locally

`cd backend && npm test` (uses built-in Node.js test runner, no libraries installed). Actual deployment, AI calls and TTS playback must be tested with real credentials. Do not assume an endpoint is live merely because the code exists.
