# Kitsune Beats release signing

See START_HERE.md for the complete release process.

- Original installation certificate: **cannot be recovered from APK** if original private key was lost.
- GitHub Actions release build uses secrets for the `.jks` + password and variable `KITSUNE_CERT_SHA256`.
- If `KITSUNE_CERT_SHA256` mismatches the signing certificate, the build fails.
- A new key is **not** an in-place upgrade for the current release: a one-time uninstall/reinstall is required.
- Never put signing material in committed source or a public repository.
