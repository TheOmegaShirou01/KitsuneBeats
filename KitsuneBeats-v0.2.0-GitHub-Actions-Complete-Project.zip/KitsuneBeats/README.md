# 🦊 Kitsune Beats v0.2.0

Android music player from **The Yamanatsuchi Initiative**, featuring Setsuna AI.

**For building on Android without Google Colab or Android Studio, start with [`START_HERE.md`](START_HERE.md).**

All APK builds are now through **GitHub Actions**. A cloud service for optional online Setsuna AI and online-user counters is in [`backend/`](backend/) and is **not deployed** by this build.

**Verification:** Backend tests and static project checks are available; app compilation and on-phone tests must happen in GitHub Actions and on a real device respectively. The original v0.1.0 keystore cannot be retrieved from this source archive.
