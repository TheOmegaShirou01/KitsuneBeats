# Development source notes

Kitsune Beats v0.2.0 Android source includes Folder/Artist/Genre tabs, local title rename, Android-approved deletion, improved search result image filtering, custom Setsuna portrait, voice search hooks, an expanded player and release checking code. The cloud service is a separate deployable template that is not live by default.

All APK builds now use GitHub Actions. Read START_HERE.md. These features require successful Android compilation and on-device testing before distribution.
