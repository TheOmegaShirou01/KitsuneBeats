# 🦊 Kitsune Beats v0.2.0 — GitHub Actions build kit

**No Google Colab needed.** The Android package ID is `com.yamanatsuchi.kitsunebeats`, version **0.2.0**, code **5**.

## 1. Create a GitHub repository

Sign in to GitHub as **TheOmegaShirou01**. Create a **private** repository named **KitsuneBeats** and put **all files inside this project's `KitsuneBeats-GitHub-Actions` directory at the root** of the repository. Hidden `.github/workflows` must be included; do not upload only the outer ZIP. If you connect this newly created repo to ChatGPT's GitHub integration, the assistant may be able to help upload the source directly. Until a repository is available, no build can run on GitHub.

## 2. Build a testable DEBUG APK first

On GitHub, open your repo → **Actions** → **Kitsune Beats - Build Android APK** → **Run workflow** → choose **debug** → **Run workflow**. Pushing the source to `main` also automatically runs a debug build. When it finishes, open the workflow run → **Artifacts** → download `KitsuneBeats-v0.2.0-debug-APK`.

**Important:** The debug APK is signed with an unrelated debug key. It **cannot update** the currently installed release-signed app. Do not uninstall your current app just to test a debug build unless you're comfortable losing its in-app settings.

## 3. Release signing: original vs lost keystore

Android requires **the same signing certificate** and package ID to install a new APK over the currently installed release. A new keystore with the same filename is NOT equivalent. You previously told us the original `Yamanatsuchi-KitsuneBeats-Release.jks` never downloaded. No available project files contain the old private key. There is no way to mathematically reconstruct it from the installed APK.

### A. If the original `.jks` is recovered (preferred)

Create the following GitHub Actions **repository secrets** in Settings → Secrets and variables → Actions:

- `KITSUNE_KEYSTORE_BASE64` = base64 of the original `.jks` contents (not its filename). Never use an online base64 converter for your private key.
- `KITSUNE_STORE_PASSWORD` = original keystore password.
- `KITSUNE_KEY_ALIAS` = original signing alias (first build used `kitsunebeats`).
- `KITSUNE_KEY_PASSWORD` = original key password.

Create a GitHub Actions **repository variable** named `KITSUNE_CERT_SHA256` with the SHA-256 fingerprint from the original, installed signed APK. This is the independent check that the release matches what is installed. The release workflow will **fail** on a mismatch.

### B. If the old key is permanently lost (one-time new identity)

**WARNING: The first APK signed with a new key cannot be installed over your old signed release.** You'll need to back up settings as possible, uninstall the old app once, and install the new release. Personal music files outside the app aren't erased by uninstalling it.

For a phone-only workflow, this kit contains an **optional, explicitly guarded** GitHub Actions job, **Recovery - Generate a NEW signing key**. It will run **only in a PRIVATE repository** and only if you check the box acknowledging a one-time uninstall/reinstall. It outputs a *highly sensitive* downloadable artifact `PRIVATE-KEY-BACKUP-KEEP-FOREVER` containing the `.jks`, random signing password, base64 value, and certificate fingerprint. Download it right away, save **two private offline backups**, enter the values into GitHub's Actions secrets/variable as the included READ_ME_FIRST.txt explains, then **delete that artifact from GitHub**. It automatically expires after one day, but you should delete it sooner. **Do not upload or commit those files to GitHub's source code or share them with anyone.**

The new key's fingerprint becomes the reference for every subsequent release. Never trigger the recovery workflow again after you have backed it up.

## 4. Build the signed release APK

Open **Actions → Kitsune Beats - Build Android APK → Run workflow**, select **release**, leave **publish_release** off while testing. GitHub runs the backend tests, builds the release using ONLY your configured keystore, verifies the APK's signing certificate matches the pinned `KITSUNE_CERT_SHA256`, and creates an artifact `KitsuneBeats-v0.2.0-release-APK` for download.

If anything is missing or wrong, **the workflow must fail** rather than make up a new key. If the old signing key was lost, don't attempt to update the old install using the new one.

## 5. Publish updates later (optional)

After you've tested the signed APK on your phone, you may make the repo **public** and re-run the signed workflow with **publish_release** enabled. This publishes v0.2.0 to GitHub Releases with the update marker `KITSUNE_VERSION_CODE=5` so Kitsune Beats can check the new version. Set the app's Settings → GitHub repository to `TheOmegaShirou01/KitsuneBeats` after the repo exists. The app will never silently bypass Android's installation approval.

## What's actually verified

The source, artwork, Android manifest and workflow file structure can be checked here, and `backend/npm test` can run. **An APK cannot be considered compiled or working until a GitHub Actions build succeeds and you test it on your Android phone.** Hosted Setsuna chat/voice and online counts require a separate Cloudflare deployment configured from `BACKEND_DEPLOYMENT.md`; they won't activate just because the APK compiles. Free-tier usage limits apply. The optional free AI voice might not match the requested custom anime-character tone exactly.
