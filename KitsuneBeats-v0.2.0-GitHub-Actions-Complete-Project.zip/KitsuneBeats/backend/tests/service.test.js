import test from 'node:test';
import assert from 'node:assert/strict';
import worker from '../src/index.js';

function testEnv(){
  const usage=new Map(), installs=new Map();
  return {
    RATE_LIMIT_SALT:'unit-test-secret',
    AI:{async run(model,input,opts){
      if(model.includes('melotts'))return new Response(new Uint8Array([73,68,51]),{headers:{'content-type':'audio/mpeg'}});
      return {response:'Hello master!'};
    }},
    DB:{
      prepare(sql){
        let args=[];
        const db={
          bind(...vals){args=vals;return db;},
          async run(){
            if(sql.startsWith('INSERT INTO rate_limits'))usage.set(args[0],(usage.get(args[0])||0)+1);
            if(sql.startsWith('INSERT INTO installations'))installs.set(args[0],args[1]);
            return {success:true};
          },
          async first(){
            if(sql.startsWith('SELECT hits'))return {hits:usage.get(args[0])||0};
            if(sql.includes('last_seen >='))return {count:[...installs.values()].filter(t=>t>=args[0]).length};
            if(sql.includes('FROM installations'))return {count:installs.size};
            return null;
          }
        };return db;
      }
    }
  };
}

test('health and missing path',async()=>{
 const env=testEnv();
 const health=await worker.fetch(new Request('https://local/health'),env);
 assert.equal(health.status,200);assert.equal((await health.json()).service,'kitsune-cloud');
 const missing=await worker.fetch(new Request('https://local/nope'),env);
 assert.equal(missing.status,404);
});
test('presence registers a device and does not double count heartbeats',async()=>{
 const env=testEnv();
 const req=()=>new Request('https://local/v1/presence',{method:'POST',
   body:JSON.stringify({installationId:'123e4567-e89b-12d3-a456-426614174000'})});
 const one=await worker.fetch(req(),env);
 assert.deepEqual((await one.json()).total,1);
 const two=await worker.fetch(req(),env);
 assert.equal((await two.json()).total,1);
 const stats=await worker.fetch(new Request('https://local/v1/stats'),env);
 const j=await stats.json();assert.equal(j.online,1);assert.equal(j.total,1);
});
test('reject malformed presence IDs',async()=>{
 const res=await worker.fetch(new Request('https://local/v1/presence',{
  method:'POST',body:JSON.stringify({installationId:'------------------------------------'})}),testEnv());
 assert.equal(res.status,400);
});
test('online Setsuna uses the included Workers AI binding, not paid API keys',async()=>{
  const res=await worker.fetch(new Request('https://local/v1/chat',{
    method:'POST',body:JSON.stringify({message:'Hello Setsuna',library:['Sonic — Sega']})}),testEnv());
  assert.equal(res.status,200);assert.equal((await res.json()).reply,'Hello master!');
});
test('speech uses the Workers AI binding',async()=>{
  const res=await worker.fetch(new Request('https://local/v1/speech',{
    method:'POST',body:JSON.stringify({text:'Hello master'})}),testEnv());
  assert.equal(res.status,200);assert.equal(res.headers.get('content-type'),'audio/mpeg');
});
test('no free Workers AI binding refuses to charge anyone',async()=>{
  const env=testEnv();delete env.AI;
  const res=await worker.fetch(new Request('https://local/v1/chat',{
    method:'POST',body:JSON.stringify({message:'Hello'})}),env);
  assert.equal(res.status,503);
});
test('limits requests per hour',async()=>{
  const env=testEnv();
  let last;
  for(let i=0;i<31;i++)last=await worker.fetch(new Request('https://local/v1/chat',{
    method:'POST',body:'{"message":"Hello"}'}),env);
  assert.equal(last.status,429);
});
