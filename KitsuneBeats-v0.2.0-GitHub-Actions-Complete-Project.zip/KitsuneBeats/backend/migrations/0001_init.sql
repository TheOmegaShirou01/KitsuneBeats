-- Anonymous installation IDs; devices are counted, not authenticated people.
CREATE TABLE IF NOT EXISTS installations (id TEXT PRIMARY KEY, last_seen INTEGER NOT NULL);
CREATE INDEX IF NOT EXISTS idx_installations_last_seen ON installations(last_seen);
CREATE TABLE IF NOT EXISTS rate_limits (id TEXT PRIMARY KEY, hits INTEGER NOT NULL, bucket INTEGER NOT NULL);
CREATE INDEX IF NOT EXISTS idx_rate_limits_bucket ON rate_limits(bucket);
